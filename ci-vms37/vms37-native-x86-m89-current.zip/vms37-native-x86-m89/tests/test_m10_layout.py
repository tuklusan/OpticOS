"""M10 ATA PIO layout and command checks (not a DOSBox execution)."""
from pathlib import Path
import subprocess,re
r=Path(__file__).resolve().parent.parent
k=(r/'src/kernel.c').read_text()
c=(r/'src/vms_ata.c').read_text()
config=(r/'dosbox-x.conf').read_text()
for x in ['port_ata_x86_read28','TEST DISK','SHOW DISK','65268','65093']:
    assert x in k
for x in ['ATA_READ=0x20','ATA_DRQ=0x08','100000u','ATA_ALTSTATUS']:
    assert x in c
assert 'imgmount 2 portdisk.img' in config
assert '-ide 1m' in config
assert 'boot vms37lab.ima' in config
syms={}
for ln in subprocess.check_output(['nm','-n',str(r/'build/kernel.elf')],text=True).splitlines():
    match=re.match(r'^([0-9A-Fa-f]+)\s+\S\s+(\S+)$',ln)
    if match:syms[match[2]]=int(match[1],16)
for x in ['port_ata_x86_read28','port_ata_read28','ata_sector','__bss_end']:
    assert x in syms
assert syms['__bss_end']<0x90000
print('M10 ATA static checks PASS: PIO driver, DOSBox-X IDE mount, guest commands')
