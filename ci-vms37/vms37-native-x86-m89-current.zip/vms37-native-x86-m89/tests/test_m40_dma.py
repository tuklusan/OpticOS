"""Emulate the BIOS request sequence from the assembly and reject 8237 DMA crossings.

This test checks the disk geometry, buffer offsets, 64KiB physical DMA boundaries,
and exact LBA-to-RAM placement for every of 251 sectors (not just ES:BX arithmetic).
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
src = (ROOT / 'src/boot.s').read_text().split('bios_read_retry:')[0]
# Interpret a deliberately small, explicit subset of 16-bit assembly.
registers = {'ax': None, 'bx': None, 'es': None, 'ah': None, 'al': None,
             'ch': None, 'cl': None, 'dh': None}
reads = []
for line in src.splitlines():
    line = line.split('/*')[0].strip()
    m = re.fullmatch(r'movw \$(0x[0-9a-fA-F]+|\d+), %([a-z]{2})', line)
    if m:
        val, reg = m.groups()
        registers[reg] = int(val, 0)
        if reg == 'ax':
            registers['ah'] = (registers['ax'] >> 8) & 255
            registers['al'] = registers['ax'] & 255
        continue
    m = re.fullmatch(r'movb \$(0x[0-9a-fA-F]+|\d+), %(ah|al|ch|cl|dh)', line)
    if m:
        val, reg = m.groups()
        registers[reg] = int(val, 0)
        continue
    if line == 'xorw %bx, %bx':
        registers['bx'] = 0
        continue
    if line == 'movw %ax, %es':
        registers['es'] = registers['ax']
        continue
    if line == 'call bios_read_retry':
        r = registers
        assert r['ah'] == 2, r
        count = r['al']
        ch, cl, dh = (r['ch'], r['cl'], r['dh'])
        assert 1 <= count <= 18
        assert 1 <= cl <= 18 and cl + count - 1 <= 18, r
        assert dh in (0, 1) and ch is not None
        phys = 16 * r['es'] + r['bx']
        assert r['bx'] + count * 512 <= 0x10000, ('ES:BX wrap', r)
        assert (phys // 0x10000) == ((phys + count * 512 - 1) // 0x10000), (
            'physical 64KiB DMA crossing', hex(phys), count)
        lba = (ch * 2 + dh) * 18 + cl - 1
        reads.append((lba, count, phys))

assert len(reads) == 15, reads
expected_lba = 1
expected_phys = 0x10000
for lba, count, phys in reads:
    assert lba == expected_lba, (lba, expected_lba)
    assert phys == expected_phys, (hex(phys), hex(expected_phys))
    expected_lba += count
    expected_phys += count * 512
assert expected_lba == 252, expected_lba
assert expected_phys == 0x2F600, hex(expected_phys)
assert (reads[7], reads[8]) == ((126, 3, 0x1FA00), (129, 15, 0x20000))
boot = (ROOT/'build/boot.bin').read_bytes()
image = (ROOT/'vms37lab.ima').read_bytes()
assert len(boot) == 512 and boot[-2:] == b'\x55\xaa'
assert len(image) == 1474560
assert image[:512] == boot
for lba, count, phys in reads:
    # A BIOS read is a direct mapping from consecutive LBA bytes into RAM.
    assert len(image[lba*512:(lba+count)*512]) == count*512
    assert 0x10000 <= phys and phys+count*512 <= 0x2F600
print('M40: 15 CHS reads, 251 contiguous sectors, 64KiB physical DMA boundary PASS')
