from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent.parent
boot=(r/'build/boot.bin').read_bytes()
assert len(boot)==512 and boot[-2:]==b'\x55\xaa'
s=(r/'src/boot.s').read_text()
assert s.count('    call bios_read_retry')>=7
assert s.count('    int $0x13')==2
assert '    movw $3, %si' in s
assert '    decw %si' in s and '    jnz .retry' in s
assert '    jmp disk_error' in s
assert '    pushw %es' in s and '    popw %es' in s
nm=subprocess.check_output(['nm',str(r/'build/boot.o')],text=True)
assert 'bios_read_retry' in nm
assert 'u->last_cr=0;' in (r/'src/vms_serial.c').read_text()
print('M37 BIOS bounded retry/reset, 7 CHS tracks, UART CRLF PASS')
