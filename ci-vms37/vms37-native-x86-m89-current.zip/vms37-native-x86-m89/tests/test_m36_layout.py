from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent.parent
s=(r/'src/kernel.c').read_text()
assert 'int serial=port_serial_x86_getc();' in s
assert 'if(serial>=0)return (char)serial;' in s
assert 'decnet_service(); continue;' in s
assert 'int port_serial_getc(' in (r/'src/vms_serial.c').read_text()
assert 'port_serial_x86_getc' in subprocess.check_output(['nm',str(r/'build/kernel.elf')],text=True)
assert len((r/'build/kernel.bin').read_bytes()) <= 251*512
print('M36 serial console RX linked and stage-1 boot limit PASS')
