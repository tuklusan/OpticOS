from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent.parent
s=(r/'src/boot.s').read_text()
assert s.count('    call bios_read_retry')==15
assert s.count('    int $0x13')==2
assert 'movw $0x1fa0, %ax' in s
assert 'movw %ax, %es' in s
assert 'xorw %bx, %bx' in s
assert 'movw $0xd200, %bx' in s
assert 'movb $6, %ch' in s and 'movb $1, %dh' in s
assert len((r/'build/boot.bin').read_bytes())==512
assert len((r/'build/kernel.bin').read_bytes())<=251*512
assert 0x1fa00+126*512==0x2f600
assert (r/'vms37lab.ima').stat().st_size==1474560
print('M39/M40 stage-1 251-sector load, CHS geometry PASS')
