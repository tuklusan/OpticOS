from pathlib import Path
p=Path(__file__).resolve().parent.parent/'portdisk.img'
b=p.read_bytes()
assert len(b)==8*16*63*512
for lba in (1,2):
    sector=b[lba*512:(lba+1)*512]
    assert sector[:16]==f'VMS37LAB-LBA{lba:04d}'.encode('ascii')
    assert sector[16:]==bytes(((i*7)+(lba*11))&255 for i in range(16,512))
assert b[0:512]==bytes(512)
print('M10 disk image PASS: CHS length, diagnostic LBA sector contents')
