from pathlib import Path
r=Path(__file__).resolve().parent.parent
s=(r/'src/boot.s').read_text()
for v in ('$0x1000','$0x8e00','$0xb200','$0xd600','$3, %ch'):
    assert v in s,v
assert s.count('call bios_read_retry')==15
assert 'bios_read_retry:' in s
assert (r/'build/boot.bin').stat().st_size==512
assert (r/'build/kernel.bin').stat().st_size<=251*512
print('M21+ stage-1 CHS loader and bounds PASS')
