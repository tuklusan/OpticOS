#!/usr/bin/env python3
"""Generate the current original-source to IA-32 function index."""
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parent.parent
REVISION = '2f5bd967bc163bdb4aa9a5e4b1f9981d9995e752'
SECTIONS = [
    (1, 80, 'src/vms_mutex.h', 'port_mutex_init', 'declarations and history'),
    (81, 118, 'src/vms_mutex.c', 'port_mutex_rwait', 'resource sleep and wait flag'),
    (119, 166, 'src/vms_mutex.c', 'port_mutex_lockwnowait', 'write attempt without sleeping'),
    (167, 202, 'src/vms_mutex.c', 'port_mutex_iolockw', 'IO database exclusive entry'),
    (203, 249, 'src/vms_mutex.c', 'port_mutex_lockw', 'write claim, pending and queue/retry'),
    (250, 285, 'src/vms_mutex.c', 'port_mutex_iolockr', 'IO database shared entry'),
    (286, 352, 'src/vms_mutex.c', 'port_mutex_lockr', 'read claim and process waiting'),
    (353, 378, 'src/vms_mutex.c', 'port_mutex_ravail', 'resource wake and pending-bit clear'),
    (379, 407, 'src/vms_mutex.c', 'port_mutex_iounlock', 'IO database release'),
    (408, 473, 'src/vms_mutex.c', 'port_mutex_unlock', 'owner count, priority restore, wakes'),
    (474, 474, None, None, 'VAX assembler end directive; no run-time action'),
]

def line_for_symbol(path, symbol):
    content = (ROOT / path).read_text().splitlines()
    for i, line in enumerate(content, 1):
        if symbol == 'port_mmg_sys_end' and 'port_mmg_sys_end:' in line:
            return i
        if symbol in ('port_bug_debug','port_mmg_pfn_patch','port_mmg_pfn_patch_desc') and re.search(r'\b'+re.escape(symbol)+r'\b',line):
            return i
        if path == 'src/boot.s' and line.lstrip().startswith(symbol + ':'):
            return i
        if path == 'build_image.py' and re.search(r'^' + re.escape(symbol) + r'\s*=', line):
            return i
        if (symbol in ('port_exe_announce','port_exe_version_quadword','types','port_bug_debug','port_mmg_pfn_patch','port_mmg_pfn_patch_desc') or symbol.startswith('port_lib_ab_')) and re.search(r'\b' + re.escape(symbol) + r'\s*\[', line):
            return i
        if (symbol in ('port_vmb_arguments','port_boot_driver_record') and
            re.search(r'\bstruct\s+' + re.escape(symbol) + r'\s*\{', line)):
            return i
        if (symbol == 'boo_default_directory' and
            re.search(r'\bboo_default_directory\s*\[', line)):
            return i
        if re.search(r'\b' + re.escape(symbol) + r'\s*\(', line) or \
           (symbol == 'port_boo_parameters' and
            re.search(r'\bstruct\s+port_boo_parameters\s*\{', line)):
            return i
    return None

result = {'source': 'https://github.com/calmsacibis995/vms37-src',
          'revision': REVISION, 'coverage_scope': 'incremental; other source files remain unresolved',
          'files': []}
segments = []
missing = 0
for begin, end, path, symbol, purpose in SECTIONS:
    if path is None:
        segments.append({'original_lines': [begin, end], 'status': 'excluded',
                         'reason': purpose})
        continue
    line = line_for_symbol(path, symbol)
    if line is None:
        missing += 1
    segments.append({'original_lines': [begin, end], 'status': 'mapped' if line else 'missing',
                     'pc_file': path, 'pc_symbol': symbol,
                     'pc_line': line, 'function': purpose})
result['files'].append({'original_file': 'SYS/SRC/MUTEX.MAR',
                        'original_lines': 474, 'sections': segments,
                        'platform_changes': ['VAX IPL replaced with serialized IA-32 interrupt-gate calls',
                                             'VAX resume PC/PSL replaced with saved IA-32 trap frame',
                                             'VAX PCB and scheduler queue replaced with native PCB and wait state']})
dcl_if_sections = [
    (1, 88, None, None, 'source header, VAX declarations and service description'),
    (89, 92, 'src/vms_dcl_if.c', 'port_dcl_if', 'set NOSTAT and evaluate binary expression'),
    (93, 96, 'src/vms_dcl_if.c', 'port_dcl_if', 'check THEN at expression cursor and test truth'),
    (97, 103, 'src/vms_dcl_if.c', 'port_dcl_if', 'dispatch true THEN command'),
    (104, 110, 'src/vms_dcl_if.c', 'port_dcl_if', 'false clause returns normal status'),
    (111, 117, 'src/vms_dcl_if.c', 'port_dcl_if', 'mark missing THEN and return CLI syntax status'),
    (118, 120, None, None, 'VAX assembler end and blank line')
]
if_mappings=[]
for begin,end,path,symbol,why in dcl_if_sections:
    if path is None:
        if_mappings.append({'original_lines':[begin,end],'status':'excluded','reason':why})
    else:
        line=line_for_symbol(path,symbol)
        if_mappings.append({'original_lines':[begin,end],'status':'mapped' if line else 'missing',
            'pc_file':path,'pc_symbol':symbol,'pc_line':line,'function':why})
        if line is None:missing+=1
result['files'].append({'original_file':'DCL/SRC/IF.MAR',
    'original_lines':120,'sections':if_mappings,
    'unresolved_integration':'DCL expression evaluation and command interpreter modules remain unfinished'})
dcl_status_sections = [
    (1, 61, None, None, 'source header and VAX declarations'),
    (62, 63, 'src/vms_dcl_status.c', 'port_dcl_set_status', 'default ON ERROR EXIT command'),
    (64, 84, None, None, 'source description and calling convention'),
    (85, 91, 'src/vms_dcl_status.c', 'port_dcl_set_status', 'ONEXIT guard, NOSTAT branch, AST disable'),
    (92, 106, 'src/vms_dcl_status.c', 'port_dcl_set_status', 'negative CLI status conversion and symbol strings'),
    (107, 112, 'src/vms_dcl_status.c', 'port_dcl_set_status', 'YLEVEL, last status and ON severity'),
    (113, 123, 'src/vms_dcl_status.c', 'port_dcl_set_status', 'flush, default EXIT, ON command and restart'),
    (124, 127, None, None, 'assembler ending and blank lines')
]
status_mappings=[]
for begin,end,path,symbol,why in dcl_status_sections:
    if path is None:
        status_mappings.append({'original_lines':[begin,end],'status':'excluded','reason':why})
    else:
        line=line_for_symbol(path,symbol)
        status_mappings.append({'original_lines':[begin,end],'status':'mapped' if line else 'missing',
            'pc_file':path,'pc_symbol':symbol,'pc_line':line,'function':why})
        if line is None:missing+=1
result['files'].append({'original_file':'DCL/SRC/STATUS.MAR',
    'original_lines':127,'sections':status_mappings,
    'unresolved_integration':'Remaining DCL command parser, symbol table and interpreter need source equivalents'})
# The original LOGIN password hash service has two algorithms: the prior
# CRC method and the VMS 3.7 Purdy polynomial. All code sections are mapped.
hpwd_sections = [
    (1, 48, None, None, 'source header, ownership notice, and history'),
    (49, 81, 'src/vms_hpwd.h', 'port_hpwd', 'descriptor and calling convention'),
    (82, 91, 'src/vms_hpwd.c', 'hpwd_crc32', 'AUTODIN-II polynomial and CRC table'),
    (92, 97, 'src/vms_hpwd.c', 'hpwd_purdy', 'Purdy coefficient constants'),
    (98, 137, None, None, 'source service description'),
    (138, 162, 'src/vms_hpwd.c', 'port_hpwd', 'CRC/Purdy algorithm selection and output'),
    (163, 178, 'src/vms_hpwd.c', 'hpwd_collapse', 'eight-byte cycling and unsigned byte additions'),
    (179, 225, 'src/vms_hpwd.c', 'hpwd_purdy', 'six-term Purdy polynomial'),
    (226, 256, 'src/vms_hpwd.c', 'hpwd_power', 'modular exponentiation'),
    (257, 272, 'src/vms_hpwd.c', 'hpwd_purdy', 'modular input reduction'),
    (273, 309, 'src/vms_hpwd.c', 'hpwd_mul', 'modular multiply without VAX EMUL'),
    (310, 328, 'src/vms_hpwd.c', 'hpwd_mul', 'unsigned multiplication on IA-32'),
    (329, 345, 'src/vms_hpwd.c', 'hpwd_mul', 'scaled modular multiplication'),
    (346, 363, 'src/vms_hpwd.c', 'hpwd_add', 'modular addition and carry handling'),
    (364, 365, None, None, 'VAX assembly end directive and blank line'),
]
hpwd = []
for begin, end, path, symbol, purpose in hpwd_sections:
    if path is None:
        hpwd.append({'original_lines': [begin, end], 'status': 'excluded',
                     'reason': purpose})
        continue
    line = line_for_symbol(path, symbol)
    if line is None:
        missing += 1
    hpwd.append({'original_lines': [begin, end],
                 'status': 'mapped' if line else 'missing',
                 'pc_file': path, 'pc_symbol': symbol, 'pc_line': line,
                 'function': purpose})
result['files'].append({'original_file': 'LOGIN/SRC/HPWD.MAR',
                        'original_lines': 365, 'sections': hpwd,
                        'platform_changes': [
                            'VAX byte and quadword operations replaced with IA-32 C operations',
                            'VAX CRC instruction replaced with the same reversed polynomial',
                            'Purdy prime arithmetic uses bounded 64-bit modular additions'
                        ]})
# LOGIN/SRC/VALIDATE.MAR maps the indexed account lookup, retry,
# password match, privilege scope and cleanup onto native storage.
validate_sections = [
    (1, 56, None, None, 'non-executable header and history'),
    (57, 131, 'src/vms_validate.h', 'port_uaf_disk_service', 'file layout, lookup statuses and buffers'),
    (132, 188, None, None, 'source service interface description'),
    (189, 193, 'src/vms_validate.c', 'port_uaf_searchuser', 'search without password'),
    (194, 228, 'src/vms_validate.c', 'port_uaf_validate', 'validation and keyed storage setup'),
    (229, 259, 'src/vms_validate.c', 'do_search', 'authorized rights, open fallback and connect'),
    (260, 298, 'src/vms_validate.c', 'do_search', 'normalize username, reject DEFAULT and use fallback'),
    (299, 313, 'src/vms_validate.c', 'do_search', 'disconnect, close and restore privilege mask'),
    (314, 326, 'src/vms_validate.c', 'locked_get', 'retry locked records with two 75-ms waits'),
    (327, 360, 'src/vms_validate.c', 'validate_password', 'upcase bounded password, call HPWD, check hash'),
    (361, 362, None, None, 'assembler end directive and blank line'),
]
validation=[]
for begin,end,path,symbol,reason in validate_sections:
    if path is None:
        validation.append({'original_lines':[begin,end],'status':'excluded','reason':reason})
    else:
        line=line_for_symbol(path,symbol)
        validation.append({'original_lines':[begin,end],
            'status':'mapped' if line else 'missing',
            'pc_file':path,'pc_symbol':symbol,'pc_line':line,'function':reason})
        if line is None: missing+=1
result['files'].append({'original_file':'LOGIN/SRC/VALIDATE.MAR',
    'original_lines':362,'sections':validation,
    'platform_changes':[
        'Native on-disk fixed-record keyed index replaces the VAX RMS indexed file layout',
        'BIOS-independent ATA PIO reads replace VAX RMS get calls',
        'Caller privilege bits remain unchanged after every completed request',
        'Only system-name lookup is permitted by the disk backend'
    ],
    'unresolved_integration': 'Reading an existing VAX RMS SYSUAF.DAT file is not yet supported; native indexed account records are used' })
# The two time functions use 100-ns VMS absolute time and the original
# Wednesday 1858-11-17 epoch. The native PC RTC provides current time.
login_time_sources = [
    ('LOGIN/SRC/LIBDAYWK.MAR', 138, [
        (1, 64, None, None, 'ownership, history and non-executable setup'),
        (65, 76, 'src/vms_logintime.c', 'port_login_day_of_week', 'offset for Monday-first count'),
        (77, 115, None, None, 'calling convention and service description'),
        (116, 126, 'src/vms_logintime.c', 'port_login_day_of_week', 'arguments and system time fallback'),
        (127, 136, 'src/vms_logintime.c', 'port_login_day_of_week', 'minutes, days and weekday'),
        (137, 138, None, None, 'assembler end directive and blank line')
    ]),
    ('LOGIN/SRC/LIBHOUR.MAR', 135, [
        (1, 74, None, None, 'ownership, history and non-executable setup'),
        (75, 113, None, None, 'calling convention and service description'),
        (114, 124, 'src/vms_logintime.c', 'port_login_hour_of_day', 'arguments and system time fallback'),
        (125, 133, 'src/vms_logintime.c', 'port_login_hour_of_day', 'minutes and hour modulo 24'),
        (134, 135, None, None, 'assembler end directive and blank line')
    ])
]
for original,length,ranges in login_time_sources:
    item=[]
    for first,last,path,symbol,reason in ranges:
        if path is None:
            item.append({'original_lines':[first,last],'status':'excluded','reason':reason})
        else:
            line=line_for_symbol(path,symbol)
            item.append({'original_lines':[first,last],
                'status':'mapped' if line else 'missing','pc_file':path,
                'pc_symbol':symbol,'pc_line':line,'function':reason})
            if line is None: missing+=1
    result['files'].append({'original_file':original,'original_lines':length,
        'sections':item, 'platform_changes':[
            'VAX GETTIM uses native CMOS RTC 100-ns absolute time conversion',
            'VMS epoch and Monday-first day numbering remain unchanged',
            'Kernel code avoids IA-32 compiler 64-bit divide runtime calls'
        ]})
# LOGIN/SRC/FILEIO.B32 centralizes primary streams and record I/O.
fileio_ranges = [
    (1, 204, 'src/vms_login_fileio.h', 'vms_lgi_fileio_init',
     'stream structures, callback interfaces, process local file state'),
    (205, 314, 'src/vms_login_fileio.c', 'vms_lgi_open_input',
     'separate or shared stream, system input/command names, executive channels'),
    (315, 336, 'src/vms_login_fileio.c', 'vms_lgi_close_input',
     'release input stream without stopping a shared output stream'),
    (337, 445, 'src/vms_login_fileio.c', 'vms_lgi_open_output',
     'output creation, resolved filename, device and error stream names'),
    (446, 470, 'src/vms_login_fileio.c', 'vms_lgi_close_output',
     'flush, display and close output'),
    (471, 547, 'src/vms_login_fileio.c', 'vms_lgi_write_file',
     '128-byte record buffer, sequential read, output and close'),
    (548, 585, 'src/vms_login_fileio.c', 'vms_lgi_write_fao',
     'ASCIC control and FAO result through library callback'),
    (586, 628, 'src/vms_login_fileio.c', 'vms_lgi_write_output',
     '30-second write timer, output record, cancellation and return zero'),
    (629, 657, 'src/vms_login_fileio.c', 'vms_lgi_write_timeout',
     'cancel input channel to end blocked output'),
    (658, 691, 'src/vms_login_fileio.c', 'vms_lgi_get_input',
     'prompt, uppercase, purge, timed input and terminal NUL'),
    (692, 693, None, None, 'BLISS module close directives')
]
fileio_segs=[]
for a,b,path,symbol,why in fileio_ranges:
    if path is None:
        fileio_segs.append({'original_lines':[a,b],'status':'excluded',
                            'reason':why})
    else:
        lineno=line_for_symbol(path,symbol)
        fileio_segs.append({'original_lines':[a,b],
                            'status':'mapped' if lineno else 'missing',
                            'pc_file':path,'pc_symbol':symbol,'pc_line':lineno,
                            'function':why})
        if lineno is None: missing+=1
result['files'].append({'original_file':'LOGIN/SRC/FILEIO.B32',
                        'original_lines':693,'sections':fileio_segs,
                        'pc_driver':'src/vms_login_uart.c',
                        'unresolved_integration':
                        'Listing files need RMS; FAOL requires full formatter; '
                        'native COM1 input/output works with current process stream map'})
cmd_segments=[]
for begin,end,path,symbol,reason in [
    (1,22,None,None,'original DEC text notice'),
    (23,26,'src/vms_logincmd.c','vms_login_parse',
     'LOGIN verb recognition and module entry'),
    (27,27,'src/vms_logincmd.c','vms_login_parse',
     'username required, USERNAME prompt when missing'),
    (28,29,'src/vms_logincmd.c','vms_login_parse',
     'DISK and CLI qualifiers with required values'),
    (30,30,'src/vms_logincmd.c','vms_login_parse',
     'default COMMAND qualifier with optional value'),
    (31,31,None,None,'trailing blank')
]:
    if path is None:
        cmd_segments.append({'original_lines':[begin,end],'status':'excluded',
                             'reason':reason})
    else:
        lineno=line_for_symbol(path,symbol)
        cmd_segments.append({'original_lines':[begin,end],
                             'status':'mapped' if lineno else 'missing',
                             'pc_file':path,'pc_symbol':symbol,'pc_line':lineno,
                             'function':reason})
        if lineno is None: missing+=1
result['files'].append({'original_file':'LOGIN/SRC/LOGINCMD.CLD',
                        'original_lines':31,'sections':cmd_segments,
                        'unresolved_integration':
                        'Original DCL CLI dispatcher is still absent; native parser is callable'})
interact_sections=[]
for first,last,symbol,meaning in [
    (1,196,'vms_lgi_interact_init','session fields, external service callbacks'),
    (197,254,'vms_lgi_init_interactive','open streams, set terminal and initial user, announce, authenticate'),
    (255,388,'vms_lgi_auto_login','SYSALF terminal lookup, privilege scope and UAF validation'),
    (389,522,'vms_lgi_interactive_validation','DCL LOGIN parse, flags, disk/CLI options, password'),
    (523,652,'vms_lgi_get_password','empty hash, local echo mask, quiet read and password check'),
    (653,710,'vms_lgi_write_announcement','logical SYS$ANNOUNCE and SYS$WELCOME, @file or literal'),
    (711,788,'vms_lgi_announce','welcome version, SYS$NODE and mail count'),
    (789,816,'vms_lgi_zero_password','erase password in input storage')
]:
    line=line_for_symbol('src/vms_login_interact.c',symbol)
    interact_sections.append({'original_lines':[first,last],
        'status':'mapped' if line else 'missing',
        'pc_file':'src/vms_login_interact.c','pc_symbol':symbol,
        'pc_line':line,'function':meaning})
    if line is None:missing+=1
interact_sections.append({'original_lines':[817,818],'status':'excluded',
                          'reason':'BLISS module close directives'})
result['files'].append({'original_file':'LOGIN/SRC/INTERACT.B32',
                        'original_lines':818,'sections':interact_sections,
                        'unresolved_integration':
                        'SYSALF native indexed file backend and real DCL image startup are absent; '
                        'guest COM1 terminal and native disk UAF access execute interactive path'})
# SYSDEF.MDL defines the original 284-byte fixed UAF record fields.
# Only this range is mapped; the rest of SYSDEF.MDL is unfinished.
result['files'].append({
    'original_file':'SHRLIB/SYSDEF.MDL',
    'status':'partial; only UAF structure mapped',
    'original_lines':6969,
    'sections':[
      {'original_lines':[6143,6146], 'status':'excluded',
       'reason':'structure introduction and source headings'},
      {'original_lines':[6147,6232], 'status':'mapped',
       'pc_file':'src/vms_uaf_v37.c','pc_symbol':'vms37_uaf_decode',
       'pc_line':line_for_symbol('src/vms_uaf_v37.c','vms37_uaf_decode'),
       'function':'VMS 3.7 UAF field offsets, password, flags and salt'},
    ],
    'unresolved_integration':'Real RMS indexed-file access and remaining original SYSDEF definitions are not yet ported'
})
# The original DCL EXIT module has two complete command entries.
dcl_exit_map=[
    (1,73,None,None,'source banner and non-executable declarations'),
    (74,104,None,None,'EXIT entry description and calling convention'),
    (105,111,'src/vms_dcl_exit.c','port_dcl_exit',
     'preserve status and evaluate optional binary expression'),
    (112,120,'src/vms_dcl_exit.c','port_dcl_exit',
     'save $STATUS and unwind one indirect command level'),
    (121,132,'src/vms_dcl_exit.c','port_dcl_exit',
     'top-level interactive image rundown or batch abort'),
    (133,150,None,None,'WAIT interface and record comments'),
    (151,169,'src/vms_dcl_exit.c','port_dcl_wait',
     'mark operand, prepend zero-day, cancel timer, BINTIM, SETIMR and WAITFR'),
    (170,171,None,None,'VAX assembler ending and blank line'),
]
new=[]
for first,last,path,symbol,reason in dcl_exit_map:
    if path:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        new.append({'original_lines':[first,last],
                    'status':'mapped' if line else 'missing',
                    'pc_file':path,'pc_symbol':symbol,'pc_line':line,
                    'function':reason})
    else:
        new.append({'original_lines':[first,last],
                    'status':'excluded', 'reason':reason})
result['files'].append({'original_file':'DCL/SRC/EXIT.MAR',
                        'original_lines':171,'sections':new,
                        'unresolved_integration':
                        'Other DCL command, parsing and process modules are not yet ported'})
# DCL/SRC/INQUIRE.MAR: full INQUIRE command, including option scanner,
# prompt text, answer compression, symbol type and scope.
inq_sections = [
    (1, 88, None, None, 'original source headings, history and call description'),
    (89, 115, 'src/vms_dcl_inquire.c', 'port_dcl_inquire_parse',
     'option prefix, symbol name and character checks'),
    (116, 140, 'src/vms_dcl_inquire.c', 'port_dcl_inquire_parse',
     'prompt string, paired quotes, default name and colon-space'),
    (141, 153, 'src/vms_dcl_inquire.c', 'port_dcl_inquire',
     'read terminal answer, compress, disable indirect and Control-Y, set symbol'),
    (154, 158, 'src/vms_dcl_inquire.c', 'port_dcl_inquire_parse',
     'invalid input syntax result'),
    (159, 198, 'src/vms_dcl_inquire.c', 'port_dcl_inquire_parse',
     'PUNCTUATION, NOPUNCTUATION, GLOBAL and LOCAL options'),
    (199, 200, None, None, 'assembler terminator and blank line'),
]
inq=[]
for first,last,path,symbol,reason in inq_sections:
    if path:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        inq.append({'original_lines':[first,last],
                    'status':'mapped' if line else 'missing',
                    'pc_file':path,'pc_symbol':symbol,'pc_line':line,
                    'function':reason})
    else:
        inq.append({'original_lines':[first,last], 'status':'excluded',
                    'reason':reason})
result['files'].append({'original_file':'DCL/SRC/INQUIRE.MAR',
                        'original_lines':200,'sections':inq,
                        'unresolved_integration':
                        'General DCL command parser and symbol engine not yet ported; '
                        'native COM1 session runs this source command and local/global symbol store'})
# DCL/SRC/ON.MAR: original ON level table, handlers, and reset entries.
on_sections = [
    (1, 61, None, None, 'source history, service declarations and descriptions'),
    (62, 69, 'src/vms_dcl_on.c', 'level', 'four-byte level table, warning/error/severe/control-Y'),
    (70, 99, None, None, 'calling convention and service description'),
    (100, 125, 'src/vms_dcl_on.c', 'port_dcl_on', 'read error level from source level table'),
    (126, 145, 'src/vms_dcl_on.c', 'port_dcl_on', 'require THEN and collect command text'),
    (146, 169, 'src/vms_dcl_on.c', 'port_dcl_on', 'command-level guard, distinct handlers and stored text'),
    (170, 198, 'src/vms_dcl_on.c', 'port_dcl_on', 'separator and syntax errors; fixed resident text means allocation cannot fail'),
    (199, 219, None, None, 'ON reset call descriptions'),
    (220, 223, 'src/vms_dcl_on.c', 'port_dcl_on_ctly_reset', 'clear CONTROL Y handler'),
    (224, 236, 'src/vms_dcl_on.c', 'port_dcl_on_reset', 'free prior handler and restore ERROR level'),
    (237, 238, None, None, 'assembler ending and blank line')
]
new=[]
for first,last,path,symbol,reason in on_sections:
    if not path:
        new.append({'original_lines':[first,last],'status':'excluded','reason':reason})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        new.append({'original_lines':[first,last],
                    'status':'mapped' if line else 'missing',
                    'pc_file':path,'pc_symbol':symbol,'pc_line':line,
                    'function':reason})
result['files'].append({'original_file':'DCL/SRC/ON.MAR',
                        'original_lines':238,'sections':new,
                        'unresolved_integration':
                        'Indirect command file processing and control-Y AST delivery require other DCL modules'})
image_sections=[
    (1, 51, None, None, 'source heading and macro description'),
    (52, 94, 'src/vms_dcl_intimages.c','port_dcl_image_lookup',
     'original 43 internal image names in order, starting with index 0x80'),
    (95, 97, None, None, 'VAX macro and assembler ending')
]
new=[]
for first,last,path,symbol,reason in image_sections:
    if not path:
        new.append({'original_lines':[first,last],
                    'status':'excluded','reason':reason})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        new.append({'original_lines':[first,last],
                    'status':'mapped' if line else 'missing',
                    'pc_file':path,'pc_symbol':symbol,'pc_line':line,
                    'function':reason})
result['files'].append({'original_file':'DCL/SRC/INTIMAGES.MAR',
                        'original_lines':97,'sections':new,
                        'unresolved_integration':
                        'Other internal DCL image implementations remain unfinished; this file defines their identifiers only'})
# The earlier source files are not marked done by this index until their
# line ranges receive the same check.
for source, target in [('SYS/SRC/ASTDEL.MAR', 'src/vms_astdel.c'),
                       ('SYS/SRC/POSTEF.MAR', 'src/vms_postef.c')]:
    result['files'].append({'original_file': source, 'status': 'line review pending',
                            'pc_file': target})
goto_sections=[
    (1, 85, None, None, 'source banner, VAX declarations and calling convention'),
    (86, 94, 'src/vms_dcl_goto.c', 'port_dcl_goto',
     'source DCL$GOTO entry, no-status flag, random access gate'),
    (95, 117, 'src/vms_dcl_goto.c', 'port_dcl_position',
     'source positioning entry and contract'),
    (118, 138, 'src/vms_dcl_goto.c', 'port_dcl_position',
     'label lookup, pending target allocation and forward scanning'),
    (139, 149, 'src/vms_dcl_goto.c', 'port_dcl_position',
     'RFA seek and sequential access restoration'),
    (150, 159, 'src/vms_dcl_goto.c', 'port_dcl_dealgoto',
     'release pending forward target control block'),
    (160, 161, None, None, 'VAX assembler ending and blank line')]

# Each source line range uses the fixed reference revision.
new=[]
for first,last,path,symbol,reason in goto_sections:
    if path:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        new.append({'original_lines':[first,last],
                    'status':'mapped' if line else 'missing',
                    'pc_file':path,'pc_symbol':symbol,'pc_line':line,
                    'function':reason})
    else:
        new.append({'original_lines':[first,last], 'status':'excluded', 'reason':reason})
result['files'].append({'original_file':'DCL/SRC/GOTO.MAR',
                        'original_lines':161,'sections':new,
                        'unresolved_integration':
                        'RMS indirect command file and DCL command interpreter are not yet complete'})
descr_sections=[
    (1, 80, None, None, 'original VAX source description and declarations'),
    (81, 100, 'src/vms_dcl_descr.c', 'port_dcl_getdval',
     'read next token, offset, flags, terminator, type, value and advance'),
    (101, 102, None, None, 'VAX assembler ending')]
parts=[]
for first,last,path,symbol,reason in descr_sections:
    if path:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        parts.append({'original_lines':[first,last],
                     'status':'mapped' if line else 'missing',
                     'pc_file':path,'pc_symbol':symbol,'pc_line':line,
                     'function':reason})
    else:
        parts.append({'original_lines':[first,last], 'status':'excluded','reason':reason})
result['files'].append({'original_file':'DCL/SRC/DESCRVAL.MAR',
   'original_lines':102,'sections':parts,
   'unresolved_integration':'Original packed PTRDEF and full DCL token parser are pending'})
# Original DCL READREC receives RMS records, expands quote-delimited
# symbols, handles special tokens, unwinds EOF and reports read errors.
readrec_ranges=[
    (1,76,None,None,'source description and machine declarations'),
    (77,97,None,None,'DCL$INPUT calling description'),
    (98,158,'src/vms_dcl_readrec.c','port_dcl_input',
     'select input level, prompt, obtain record, skip GOTO scan lines'),
    (159,201,'src/vms_dcl_readrec.c','port_dcl_input',
     'substitution, VERIFY, comments, trailing space and prompt'),
    (202,287,'src/vms_dcl_readrec.c','port_dcl_input',
     'RMS$_RSA retry/cancel, EOF unstack, batch end, other read errors'),
    (288,296,'src/vms_dcl_readrec.c','port_dcl_silent_logout',
     'silent process exit with completion status'),
    (297,317,None,None,'EXPAND calling description'),
    (318,359,'src/vms_dcl_readrec.c','port_dcl_expand',
     'quoted string state, paired quote and comment scan'),
    (360,430,'src/vms_dcl_readrec.c','port_dcl_expand',
     'local/global lookup, lexical fallback, recursive expansion bound'),
    (431,449,'src/vms_dcl_readrec.c','port_dcl_expand',
     'replace source line with expanded input and reset cursor'),
    (450,469,None,None,'SPECIAL calling description'),
    (470,476,'src/vms_dcl_readrec.c','port_dcl_special',
     'dispatch special ampersand and at-sign tokens'),
    (477,494,None,None,'ampersand calling description'),
    (495,507,'src/vms_dcl_readrec.c','port_dcl_special',
     'replace ampersand symbol with its value'),
    (508,523,None,None,'indirect calling description'),
    (524,534,'src/vms_dcl_readrec.c','port_dcl_special',
     'disable indirection, push frame and resume record input'),
    (535,548,None,None,'character error calling description'),
    (549,555,'src/vms_dcl_readrec.c','port_dcl_charerror',
     'report, flush input, set status and restart'),
    (556,558,None,None,'VAX assembler terminator and blank lines')]
parts=[]
for first,last,path,symbol,reason in readrec_ranges:
    if not path:
        parts.append({'original_lines':[first,last],'status':'excluded','reason':reason})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        parts.append({'original_lines':[first,last],
                      'status':'mapped' if line else 'missing',
                      'pc_file':path,'pc_symbol':symbol,'pc_line':line,
                      'function':reason})
result['files'].append({
    'original_file':'DCL/SRC/READREC.MAR','original_lines':558,'sections':parts,
    'unresolved_integration':
    'RMS file lookup and arbitrary VMS procedure files require other source modules; '
    'COM1 and lab IDE sector records currently provide the real record source.'})
# DCL startup: original INITIAL.MAR services run in native process space.
# The VAX call-frame and supervisor stack instructions become a C entry.
initial_ranges = [
    (1,101,None,None,'copyright notice, history and non-executable comments'),
    (102,115,'src/vms_dcl_initial.h','port_dcl_initial_start','PPD/PRC/RMS/indirect/spawn data declarations'),
    (116,124,'src/vms_dcl_initial.c','port_dcl_initial_start','SYS$ERROR logical and table setup'),
    (125,133,'src/vms_dcl_initial.c','port_dcl_initial_set_status','permanent $STATUS and $SEVERITY symbols'),
    (134,149,'src/vms_dcl_initial.c','port_dcl_initial_start','native entry instead of a VAX supervisor call frame'),
    (150,176,'src/vms_dcl_initial.c','port_dcl_initial_start','process data, input channel, mode, AST and table pointer'),
    (177,199,'src/vms_dcl_initial.c','port_dcl_initial_start','ON ERROR defaults and local/global/label symbol lists'),
    (200,219,'src/vms_dcl_initial.c','port_dcl_initial_start','permanent symbol allocation and pointers'),
    (220,252,'src/vms_dcl_initial.c','port_dcl_initial_start','batch P1-P8 process logical lookup and hex FF null'),
    (253,303,'src/vms_dcl_initial.c','port_dcl_initial_start','FAB/NAM/RAB structures, shared streams and prompt flags'),
    (304,332,'src/vms_dcl_initial.c','port_dcl_initial_start','nine zeroed 112-byte indirect frames and initial I/O state'),
    (333,359,'src/vms_dcl_initial.c','port_dcl_initial_start','PROC# startup files in descending order'),
    (360,365,'src/vms_dcl_initial.c','port_dcl_initial_start','LOGIN process rundown'),
    (366,400,'src/vms_dcl_initial.c','port_dcl_initial_start','parent PID, supervisor SYS$ERROR mailbox validation'),
    (401,425,'src/vms_dcl_initial.c','port_dcl_initial_start','table versions 2-5, Control-Y mask and native entry restart'),
    (426,435,'src/vms_dcl_initial.c','startup_fail','error handling and process abort'),
    (436,455,None,None,'spawn interface description'),
    (456,499,'src/vms_dcl_initial.c','port_dcl_initial_start','context mailbox read, sender verification and close'),
    (500,526,'src/vms_dcl_initial.c','port_dcl_initial_spawn_record','privilege header and context flags'),
    (527,542,'src/vms_dcl_initial.c','port_dcl_initial_spawn_record','pending command copy and flag'),
    (543,563,'src/vms_dcl_initial.c','port_dcl_initial_spawn_record','access-mode checked process logical definition'),
    (564,597,'src/vms_dcl_initial.c','port_dcl_initial_spawn_record','global/local string, permanent and binary symbols'),
    (598,617,'src/vms_dcl_initial.c','port_dcl_get_prc','CLI$GET_PRC state pointer'),
    (618,619,None,None,'assembler end')
]
initial_parts=[]
for a,b,path,symbol,reason in initial_ranges:
    if path is None:
        initial_parts.append({'original_lines':[a,b],'status':'excluded','reason':reason})
    else:
        lineno=line_for_symbol(path,symbol)
        if not lineno:missing+=1
        initial_parts.append({'original_lines':[a,b],
              'status':'mapped' if lineno else 'missing',
              'pc_file':path,'pc_symbol':symbol,'pc_line':lineno,'function':reason})
result['files'].append({'original_file':'DCL/SRC/INITIAL.MAR',
    'original_lines':619,'sections':initial_parts,
    'platform_changes':['VAX call frames replaced by direct native C calls',
                        'VAX Control-Y setup uses IA-32 AST process mask',
                        'RMS record blocks keep their source-defined lengths and streams'],
    'unresolved_integration': 'A real supervisor mailbox and SPAWN caller must supply context records. Native DCL startup is invoked at real COM1 login.'})
# DCL/SRC/COMMAND.MAR owns command setup, parsing, image dispatch and restart.
# The native interpreter calls the same source-defined services through ops.
command_ranges = [
    (1,143,None,None,'source history, ownership notice and description'),
    (144,164,'src/vms_dcl_command.h','port_dcl_cmd_start','source work fields and two command prompts'),
    (165,184,None,None,'command processing call description'),
    (185,189,'src/vms_dcl_command.c','port_dcl_command_run','restart and input cursor'),
    (190,211,None,None,'processing entry description'),
    (212,244,'src/vms_dcl_command.c','port_dcl_cmd_start','reset parse work, prompt, AST state and result array'),
    (245,273,'src/vms_dcl_command.c','port_dcl_command_run','Control-Y pending, pending command and chain selection'),
    (274,300,'src/vms_dcl_command.c','process','hangup, null lines, leading dollar, first nonblank'),
    (301,314,'src/vms_dcl_command.c','token_name','first symbol, verb or label'),
    (315,353,'src/vms_dcl_command.c','process','label tables, GOTO target and indirect level checks'),
    (354,369,'src/vms_dcl_command.c','parse_assign','string symbol equal statement'),
    (370,391,'src/vms_dcl_command.c','parse_assign','substring and arithmetic symbol assignments'),
    (392,423,'src/vms_dcl_command.c','process','command symbol expansion, comments and indirect invocation'),
    (424,459,'src/vms_dcl_command.c','procedure','foreign and indirect file command routing'),
    (460,485,'src/vms_dcl_command.c','process','native verb table lookup and image type'),
    (486,515,'src/vms_dcl_command.c','option','slash option, keyword and value routing'),
    (516,586,'src/vms_dcl_command.c','parameters','parameter delimiters, lists, joining and count limits'),
    (587,624,'src/vms_dcl_command.c','parameters','required input and extra parameter prompt handling'),
    (625,647,'src/vms_dcl_command.c','process','external and internal image selection'),
    (648,717,'src/vms_dcl_command.c','order_internal','result token ordering and native image dispatch'),
    (718,739,'src/vms_dcl_command.c','process','privileged image rundown with CONTINUE SPAWN ATTACH exceptions'),
    (740,747,'src/vms_dcl_command.c','fail','completion status and message report'),
    (748,763,'src/vms_dcl_command.c','process','internal image number routing to source image services'),
    (764,789,'src/vms_dcl_command.c','port_dcl_cmd_abort','force LOGOUT from hangup or abort'),
    (790,810,'src/vms_dcl_command.c','port_dcl_cmd_eod','EOD no-status and DECK invalid value'),
    (811,832,'src/vms_dcl_command.c','port_dcl_cmd_check_ast','Control-Y restart check'),
    (833,864,'src/vms_dcl_command.c','port_dcl_cmd_disable','nested AST disable and restore'),
    (865,893,'src/vms_dcl_command.c','port_dcl_cmd_flush','nonterminal input flush and indirect suppression'),
    (894,952,'src/vms_dcl_command.c','parameters','table prompt lookup and continuation answer'),
    (953,986,'src/vms_dcl_command.c','process','foreign image tail preservation'),
    (987,988,None,None,'VAX assembler terminator and blank line')
]
command_parts=[]
for a,b,path,symbol,reason in command_ranges:
    if path is None:
        command_parts.append({'original_lines':[a,b],'status':'excluded','reason':reason})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        command_parts.append({'original_lines':[a,b],
            'status':'mapped' if line else 'missing','pc_file':path,
            'pc_symbol':symbol,'pc_line':line,'function':reason})
result['files'].append({'original_file':'DCL/SRC/COMMAND.MAR',
    'original_lines':988,'sections':command_parts,
    'platform_changes':['VAX command stack and result table mapped to native C parse state',
                        'Image vector dispatch uses native function calls',
                        'RMS input and indirect record positioning use service callbacks'],
    'unresolved_integration': 'DCLTABLES full grammar and external image execution belong to other source modules and are not yet available. Native guest currently registers only implemented verbs.'})

# REMACP remote-terminal CONFIGURE and DISCONNECT data and functions.
# Source: REM/SRC/REMPROTCL.MAR; REMDEF version and ECO in REM/SRC/REMMACROS.MAR.
rem_protocol_ranges = [
    (1,62,None,None,'ownership notice, history, source declarations'),
    (63,78,'src/vms_rem_protocol.h','port_rem_protocol_init','REM data and native terminal state'),
    (79,85,'src/vms_rem_protocol.c','port_rem_send_config','eight-byte VMS CONFIGURE template'),
    (86,93,'src/vms_rem_protocol.c','rem_disconnect','disconnect wire type and reason'),
    (94,116,None,None,'protocol service description and calling convention'),
    (117,134,'src/vms_rem_protocol.c','port_rem_protocol_receive','CONFIGURE tag, peer version, support bit'),
    (135,155,'src/vms_rem_protocol.c','port_rem_protocol_receive','common version and minimum ECO'),
    (156,165,'src/vms_rem_protocol.c','port_rem_protocol_receive','eight-byte characteristics and ECO extended longword'),
    (166,179,'src/vms_rem_protocol.c','port_rem_protocol_receive','online flag, verify channel, network window and RTT attention'),
    (180,185,'src/vms_rem_protocol.c','rem_kill','bad message kills the device'),
    (186,197,'src/vms_rem_protocol.c','rem_disconnect','write DISCONNECT with completion cleanup'),
    (198,205,'src/vms_rem_protocol.c','port_rem_send_config','send original CONFIGURE without completion callback'),
    (206,215,None,None,'description of asynchronous DISCONNECT completion'),
    (216,220,'src/vms_rem_protocol.c','port_rem_send_complete','remove channel on DISCONNECT write completion'),
    (221,223,None,None,'assembler end and blank line')
]
parts=[]
for begin,end,path,symbol,why in rem_protocol_ranges:
    if path is None:
        parts.append({'original_lines':[begin,end],'status':'excluded','reason':why})
    else:
        line=line_for_symbol(path,symbol)
        if not line:missing+=1
        parts.append({'original_lines':[begin,end],
            'status':'mapped' if line else 'missing','pc_file':path,
            'pc_symbol':symbol,'pc_line':line,'function':why})
result['files'].append({'original_file':'REM/SRC/REMPROTCL.MAR',
    'original_lines':223,'sections':parts,
    'platform_changes':['UCB data and network window stored in native PC terminal state',
                        'VAX JSB and AST calls use native channel/attention/send callbacks'],
    'unresolved_integration':'The REMACP listener, RTTDRIVER and NSP object 23 connection are not yet linked to live network sessions.'})

# SYS/SRC/BOOPARAM.MAR: exact 96-byte SYSBOOT/INIT parameter cells.
booparam_ranges=[
    (1,87,None,None,'source header, history and parameter descriptions'),
    (88,93,'src/vms_booparam.h','port_boo_parameters','start of bootstrap parameter block'),
    (94,108,'src/vms_booparam.h','port_boo_parameters','driver pointers, INILOA and nonpaged pool'),
    (109,120,'src/vms_booparam.h','port_boo_parameters','IRP, LRP and SRP split/count storage'),
    (121,128,'src/vms_booparam.h','port_boo_parameters','file cache, BOOTCB, TOPSYS and SCS ID'),
    (129,136,'src/vms_booparam.h','port_boo_parameters','port driver, microcode, SCS load and size'),
    (137,138,None,None,'assembler end and blank line')
]
segments=[]
for first,last,path,symbol,reason in booparam_ranges:
    if path is None:
        segments.append({'original_lines':[first,last],'status':'excluded','reason':reason})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        segments.append({'original_lines':[first,last],
                         'status':'mapped' if line else 'missing',
                         'pc_file':path,'pc_symbol':symbol,'pc_line':line,'function':reason})
result['files'].append({'original_file':'SYS/SRC/BOOPARAM.MAR',
                       'original_lines':138,'sections':segments,
                       'platform_changes':['Native 32-bit parameter fields keep the original offsets',
                                           'SYSBOOT to INIT handoff copies all original fields'],
                       'unresolved_integration':'SYSBOOT still has to load actual system images and set parameters before SYSINIT can run.'})

# Native SYSBOOT console, BOOTS/SRC/READPRMPT.MAR. Source data offsets
# and the QIO read, QIO write and RIO output entries use the same device.
boot_console_ranges = [
    (1,65,None,None,'source header, history and parameter descriptions'),
    (66,84,'src/vms_boot_readprompt.h','port_boo_console_init','QIO IOSB, _OPA0 channel and 256-byte RIO buffer'),
    (85,119,None,None,'read/write interface and calling description'),
    (120,129,'src/vms_boot_readprompt.c','port_boo_readprompt','lazy channel assignment for _OPA0'),
    (130,135,'src/vms_boot_readprompt.c','port_boo_readprompt','prompt length and counted record'),
    (136,146,'src/vms_boot_readprompt.c','port_boo_readprompt','QIO READPROMPT and IOSB byte count'),
    (147,156,'src/vms_boot_readprompt.c','port_boo_readprompt','output-only QIO WRITEVBLK and return status'),
    (157,169,None,None,'RIO output line entry description'),
    (170,185,'src/vms_boot_readprompt.c','port_rio_output_line','append CR LF and use output-only BOO readprompt'),
    (186,186,None,None,'assembler end and blank line')
]
sections=[]
for first,last,path,symbol,reason in boot_console_ranges:
    if path is None:
        sections.append({'original_lines':[first,last],'status':'excluded',
                         'reason':reason})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        sections.append({'original_lines':[first,last],
                         'status':'mapped' if line else 'missing',
                         'pc_file':path,'pc_symbol':symbol,'pc_line':line,
                         'function':reason})
result['files'].append({'original_file':'BOOTS/SRC/READPRMPT.MAR',
                       'original_lines':186,'sections':sections,
                       'platform_changes':['SYSBOOT _OPA0 QIO calls map to the native serial console',
                                           'VAX IOSB is represented by native 16-bit status and count cells'],
                       'unresolved_integration':'SYSBOOT, SYSINIT, RMS/F11 disk mounting and STARTUP.COM are not yet ready. Startup stops rather than enter LOGINOUT without them.'})

# SYS/SRC/INITVEC.MAR is the INILOA loadable-entry linkage descriptor.
initvec_ranges = [
    (1,73,None,None,'source conditions, history and vector description'),
    (74,110,'src/vms_initvec.c','port_ini_vectors_link','source LOADVEC layout and self-relative entry resolution'),
    (111,112,None,None,'VAX program-section select for loadable image'),
    (113,134,'src/vms_initvec.c','port_ini_vectors_link','validate loadable code header and image length'),
    (135,145,'src/vms_initvec.c','port_ini_vectors_init','initial unresolved SYS.EXE vector'),
    (146,152,'src/vms_initvec.c','port_ini_vectors_link','INI$IOMAP type-3 entry and end marker'),
    (153,154,None,None,'assembler end and whitespace')
]
segments=[]
for begin,end,path,symbol,why in initvec_ranges:
    if path is None:
        segments.append({'original_lines':[begin,end],'status':'excluded','reason':why})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        segments.append({'original_lines':[begin,end],
                         'status':'mapped' if line else 'missing',
                         'pc_file':path,'pc_symbol':symbol,'pc_line':line,
                         'function':why})
result['files'].append({'original_file':'SYS/SRC/INITVEC.MAR',
                       'original_lines':154,'sections':segments,
                       'platform_changes':['VAX JMP vector stores a verified native IA-32 entry address',
                                           'INILOA self-relative code header and type-3 offset are checked'],
                       'unresolved_integration':'INILOA.EXE is loaded from Files-11 into guest supervisor RAM, but INIT has not linked/entered INI$IOMAP; no guest I/O database or RPB handoff yet.'})

# BOOTS/SRC/BOOTIO.MAR: bootstrap device I/O, file cache and image attributes.
# Parameter-file loading is in SYSBOOT.MAR, not in this module.
bootio_sections=[
    (1,68,None,None,'source ownership, history and descriptions'),
    (69,87,'src/vms_bootio.c','boo_cache_alloc','cache sizing macro (90 percent threshold, four-page alignment)'),
    (88,140,None,None,'source service description and calling parameters'),
    (141,153,'src/vms_bootio.c','boo_rdwr_lbn','RPB bootstrap driver with physical memory mode'),
    (154,190,None,None,'source cache description and arguments'),
    (191,206,'src/vms_bootio.c','boo_cache_alloc','MEM_CACHE_TABLE original nine choices including zero sentinel'),
    (207,212,None,None,'source page allocation notes'),
    (213,230,'src/vms_bootio.c','boo_cache_alloc','select first matching cache size and usable pages'),
    (231,233,None,None,'source cache open description'),
    (234,239,'src/vms_bootio.c','boo_cache_init','allocate then open cache'),
    (240,256,'src/vms_bootio.c','boo_cache_open','initialize FIL$CACHE_INIT descriptor and directory cache'),
    (257,269,None,None,'source physical-page scan description'),
    (270,286,'src/vms_bootio.c','boo_alloc_pages','scan RPB valid bits, accept half or full contiguous cache'),
    (287,309,None,None,'source image attribute description'),
    (310,332,'src/vms_bootio.c','boo_image_attributes','image debug/global symbol and patch VBN trim'),
    (333,361,None,None,'source bootstrap SYS$ASSIGN description'),
    (362,367,'src/vms_bootio.c','boo_assign','return RPB address as source bootstrap channel'),
    (368,374,None,None,'source notes for bootstrap default directories'),
    (375,379,'src/vms_bootio.c','boo_default_directory','FIL$GT_DDSTRING and empty default device'),
    (380,381,None,None,'end of source')
]
segments=[]
for first,last,path,symbol,why in bootio_sections:
    if path is None:
        segments.append({'original_lines':[first,last],'status':'excluded',
                         'reason':why})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        segments.append({'original_lines':[first,last],
                         'status':'mapped' if line else 'missing',
                         'pc_file':path,'pc_symbol':symbol,'pc_line':line,'function':why})
result['files'].append({'original_file':'BOOTS/SRC/BOOTIO.MAR',
                       'original_lines':381,'sections':segments,
                       'platform_changes':['VAX RPB I/O vector is a native PC disk service',
                                           'VAX PFN bitmap is a native byte bitmap',
                                           'Image header offsets are supplied from the image type'],
                       'unresolved_integration':'The original FIL$OPENFILE path for SYS.EXE and other system images is not complete; the current raw IDE test disk has no Files-11 home block.'})

# BOOTS/SRC/BOOTBLOCK.MAR: the entire original boot-block job has a PC
# counterpart. BIOS replaces the VAX ROM LBN reader and the VAX UNIBUS
# address conversion is inapplicable to native IA-32 physical memory.
bootblock_sections=[
    (1,55,None,None,'original DEC source history and layout explanation'),
    (56,63,'src/boot.s','stage2_magic','boot file size, first LBN and kernel destination'),
    (64,153,None,None,'VAX UNIBUS/MASSBUS inputs and explanatory comments; PC uses BIOS drive number'),
    (154,174,'src/boot.s','_start','bootstrap metadata and physical load address'),
    (175,179,'src/boot.s','read_block','BIOS CHS block read and persistent disk-error halt'),
    (180,186,'src/boot.s','next_block','advance destination and LBN; decrement remaining count'),
    (187,195,'src/boot.s','protected_entry','enter IA-32 protected mode and transfer to the loaded image'),
    (196,198,None,None,'VAX-only UNIBUS CSR masking; no UNIBUS in a native PC'),
    (199,201,None,None,'source end directive and blank lines')]
boot_sections=[]
for first,last,path,symbol,why in bootblock_sections:
    if path is None:
        boot_sections.append({'original_lines':[first,last],
                             'status':'excluded','reason':why})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        boot_sections.append({'original_lines':[first,last],
                     'status':'mapped' if line else 'missing',
                     'pc_file':path,'pc_symbol':symbol,'pc_line':line,
                     'function':why})
result['files'].append({'original_file':'BOOTS/SRC/BOOTBLOCK.MAR',
   'original_lines':201,'sections':boot_sections,
   'platform_changes':['VAX ROM block read replaced by PC BIOS INT 13h',
                       'VAX swapped LBN fields replaced by native little-endian LBN',
                       'PC loads executable to physical 0x10000 and enters protected mode',
                       'BIOS boot sector stores block count outside its instruction entry']})

# SYSBOOT and FILEREAD are only partly ported. Do not record these
# original files as complete until their remaining source is implemented.
sysboot_read_ranges=[
    (1,656,None,None,'SYSBOOT machine setup, image loading and other entries','missing'),
    (657,674,'src/vms_sysboot_read.c','port_sysboot_getcurrent','GETCURRENT locates SYS.EXE through Files-11','mapped'),
    (675,724,'src/vms_sysboot_read.c','port_sysboot_getcurrent','SYS.EXE file header and executable region','mapped'),
    (725,750,'src/vms_sysboot_read.c','port_sysboot_getcurrent','SYSPARAM VBN mapping and disk block transfer','mapped'),
    (751,1958,None,None,'remaining early SYSBOOT setup, memory, CPU and image driver startup','missing'),
    (1959,1992,'src/vms_sysboot_read.c','port_sysboot_image_init','IMAGE_OPEN resolves the image and its file header','mapped'),
    (1993,2008,None,None,'fatal scattered-file messages and IMAGE_INIT description','missing'),
    (2009,2056,'src/vms_sysboot_read.c','port_sysboot_image_init','IMAGE_INIT reads file image header and executable block range','mapped'),
    (2057,2160,None,None,'SYSBOOT missing image diagnostics, directory and pool setup','missing'),
    (2161,2211,'src/vms_sysboot_read.c','port_sysboot_load_code','LOAD_CODE reads executable bytes from Files-11','mapped'),
    (2212,2263,'src/vms_sysboot_map.c','port_sysboot_setmap','BOO$SETMAP normalizes a segment of the block map','mapped'),
    (2264,2280,'src/vms_sysboot_map.c','port_sysboot_mapvbn','BOO$MAPVBN resolves one-origin virtual blocks','mapped'),
    (2281,2339,None,None,'other SYSBOOT block reading and data setup','missing'),
    (2340,2399,'src/vms_sysboot_read.c','port_sysboot_read_virtual','READ_VIRTUAL reads the mapped file region','mapped'),
    (2400,2897,None,None,'QIO_RWLB queue logic, conversational parameter files and other SYSBOOT services','missing')
]
sections=[]
for first,last,path,symbol,reason,status in sysboot_read_ranges:
    if path is None:
        sections.append({'original_lines':[first,last],'status':status,'reason':reason})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        sections.append({'original_lines':[first,last],
                         'status':'mapped' if line else 'missing',
                         'pc_file':path,'pc_symbol':symbol,'pc_line':line,
                         'function':reason})
result['files'].append({'original_file':'BOOTS/SRC/SYSBOOT.MAR',
                       'original_lines':2897,'sections':sections,
                       'platform_changes':['Native IA-32 SYS.EXE is a separately linked ELF32 file installed in the original Files-11 directory; the VAX image record format is CPU-specific', 'SYSBOOT ELF32 LOAD_CODE streams real PT_LOAD bytes from the F11 VBN map into reserved supervisor RAM'],
                       'unresolved_integration':'Original SYSPARAM/INIT data layout and GETCURRENT processing remain incomplete. SYS.EXE and INILOA load into guest RAM but other images/entry points are still missing.'})

fileread_sections=[
    (1,740,None,None,'other FILEREAD declarations, cache setup, full filename parser and open logic','missing'),
    (741,866,'src/vms_boot_files11.c','port_f11_mount','FIL$MOUNT Files-11 structure level 2 and index header validation','mapped'),
    (867,1000,None,None,'directory cache and original argument frame are unfinished','missing'),
    (1001,1215,'src/vms_boot_files11.c','port_f11_find_file','directory header and level 2 directory record scan','mapped'),
    (1216,1377,None,None,'directory cache, level 1 search and other unported paths','missing'),
    (1378,1494,'src/vms_boot_files11.c','port_f11_read_file_header','indexed file header and checksums','mapped'),
    (1495,1545,'src/vms_boot_files11.c','port_f11_collect_file_extents','follow file header FID chain, combine normalized extents, detect cycles and overflow','mapped'),
    (1546,1635,'src/vms_boot_files11.c','port_f11_read_vbn','VBN to LBN and disk block reads','mapped'),
    (1636,1760,'src/vms_boot_files11.c','read_pointer','structure level 2 retrieval pointer formats','mapped'),
    (1761,1870,'src/vms_boot_files11.c','port_f11_file_extent_stats','file allocation count and contiguous LBN','mapped'),
    (1871,1999,'src/vms_boot_files11.c','port_f11_read_file_header','file ID and checksum validation, level 2 only','mapped')
]
sections=[]
for first,last,path,symbol,reason,status in fileread_sections:
    if path is None:
        sections.append({'original_lines':[first,last],'status':status,'reason':reason})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        sections.append({'original_lines':[first,last],
                         'status':'mapped' if line else 'missing',
                         'pc_file':path,'pc_symbol':symbol,'pc_line':line,
                         'function':reason})
result['files'].append({'original_file':'SYS/SRC/FILEREAD.MAR',
                       'original_lines':1999,'sections':sections,
                       'unresolved_integration':'Structure level 1, numeric/UIC directories, directory cache, full FIL$OPENFILE and remaining error cases need work.'})

# SYSINIT remains incomplete. Only its three source-defined system
# logical names and translation loop have a native implementation.
sysinit_sections = [
    (1,311,None,None,'SYSINIT other storage and service definitions are missing','missing'),
    (312,332,'src/vms_sysinit_names.c','port_sip_create_system_names','system logical name table and directory strings','mapped'),
    (333,528,None,None,'other startup process and disk descriptors remain missing','missing'),
    (529,562,None,None,'entry and service description','excluded'),
    (563,577,None,None,'process entry and lockdown are not implemented','missing'),
    (578,628,'src/vms_sysinit_names.c','port_sip_create_system_names','TRNLOG SYS$SYSDEVICE, strip underscore, append directory, CRELOG system table','mapped'),
    (629,1905,None,None,'time setup, paging/swap, RMS, F11ACP, SYSMSG and STARTUP not implemented','missing')
]
sections=[]
for first,last,path,symbol,reason,status in sysinit_sections:
    if path is None:
        sections.append({'original_lines':[first,last],'status':status,'reason':reason})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        sections.append({'original_lines':[first,last],
                         'status':'mapped' if line else 'missing','pc_file':path,
                         'pc_symbol':symbol,'pc_line':line,'function':reason})
result['files'].append({'original_file':'SYSINI/SRC/SYSINIT.MAR',
                       'original_lines':1905,'sections':sections,
                       'unresolved_integration':'No complete native SYSINIT process, no login until required services run.'})

# Original INIT disk creation modules. One full original source file per
# section group, with source line ranges mapped by actual PC function names.
init_disk_sources = [
    ('INIT/SRC/INIMFD.B32',257,[
        (1,88,None,None,'source notice, setup and comment lines'),
        (89,196,'src/vms_init_mfd.c','port_init_mfd','fixed ODS-1 RAD50 and ODS-2 MFD file IDs and records'),
        (197,255,'src/vms_init_mfd.c','port_init_mfd','initial MFD block write through disk service'),
        (256,257,None,None,'BLISS source close')]),
    ('INIT/SRC/INIBIT.B32',262,[
        (1,69,None,None,'source notice and service description'),
        (70,145,'src/vms_init_bitmap.c','port_init_bitmap','initial bitmap output and allocation-table input'),
        (146,187,'src/vms_init_bitmap.c','port_init_bitmap','SCB structure levels, CHS details and checksum'),
        (188,258,'src/vms_init_bitmap.c','port_init_bitmap','sorted cluster allocation, bitmap bits and zero-filled tail'),
        (259,262,None,None,'BLISS source close')]),
    ('INIT/SRC/ININDX.B32',650,[
        (1,90,None,None,'source notice and data descriptions'),
        (91,182,'src/vms_init_index.c','port_init_index','native BIOS non-system boot block and initial file header fields'),
        (183,315,'src/vms_init_index.c','port_init_index','INIT_INDEX allocation metadata, boot and home block construction'),
        (316,364,'src/vms_init_index.c','port_init_index','home copies and initial index bitmap'),
        (365,505,'src/vms_init_index.c','port_init_index','nine reserved headers and their original file data and maps'),
        (506,564,'src/vms_init_index.c','home_block','two home block checksums and sequential LBN updates'),
        (565,649,'src/vms_init_index.c','make_pointer','format one, two and three retrieval pointers'),
        (650,650,None,None,'BLISS source close')]),
    ('MOUNT/SRC/CHKSM2.B32',119,[
        (1,79,None,None,'source notice and interface description'),
        (80,116,'src/vms_f11_home.c','port_f11_checksum2','16-bit additive checksum and writeback'),
        (117,119,None,None,'BLISS source close')]),
    ('MOUNT/SRC/CHKHM1.B32',138,[
        (1,63,None,None,'original DEC source notice and interface description'),
        (64,108,'src/vms_f11_home.c','port_f11_check_home1','ODS-1 inputs and required nonzero fields'),
        (109,136,'src/vms_f11_home.c','port_f11_check_home1','checksums, two structure versions and zero-padded label'),
        (137,138,None,None,'BLISS source end')]),
    ('MOUNT/SRC/CHKHM2.B32',143,[
        (1,105,None,None,'source notice and interface description'),
        (106,140,'src/vms_f11_home.c','port_f11_check_home2','home block fields, two sums and padded label'),
        (141,143,None,None,'BLISS source close')])
]
for original,length,ranges in init_disk_sources:
    sections=[]
    for first,last,path,symbol,reason in ranges:
        if path is None:
            sections.append({'original_lines':[first,last], 'status':'excluded', 'reason':reason})
        else:
            line=line_for_symbol(path,symbol)
            if line is None: missing+=1
            sections.append({'original_lines':[first,last],
                'status':'mapped' if line else 'missing',
                'pc_file':path,'pc_symbol':symbol,'pc_line':line,'function':reason})
    result['files'].append({'original_file':original,'original_lines':length,
        'sections':sections,
        'platform_changes':(['PDP-11 non-system bootblock code uses the same warning and halt on IA-32']
            if original=='INIT/SRC/ININDX.B32' else []),
        'unresolved_integration':'The full INIT utility, SYS.EXE and its loadable system images remain unfinished.'})


# SYS/SRC/FILERWIO.MAR: complete callable FIL$RDWRTLBN variant.
# The bootstrap uses BOOTIO's RPB driver form; FILERWIO is the QIOW form.
filerwio_ranges=[
    (1,101,None,None,'source license, history, declarations and API description'),
    (102,103,'src/vms_filerwio.c','port_filerwio_rdwr_lbn','entry and frame setup'),
    (104,115,'src/vms_filerwio.c','port_filerwio_rdwr_lbn','eight-byte IOSB, QIOW call and IOSB/service status choice'),
    (116,118,None,None,'assembler end directive, blank line')
]
# Read the exact source line count in future updates before changing this range.
fr=[]
for first,last,path,sym,why in filerwio_ranges:
    if path is None:fr.append({'original_lines':[first,last], 'status':'excluded','reason':why})
    else:
        line=line_for_symbol(path,sym)
        if line is None:missing+=1
        fr.append({'original_lines':[first,last],'status':'mapped' if line else 'missing',
                   'pc_file':path,'pc_symbol':sym,'pc_line':line,'function':why})
result['files'].append({'original_file':'SYS/SRC/FILERWIO.MAR',
                        'original_lines':118,'sections':fr,
                        'platform_changes':['QIOW is a native PC disk service; separate queue and IOSB status are retained']})

# BOOTS/SRC/BOOTS.MAR: all non-comment macro instructions translate to
# IA-32 boot driver table entries and the VMB -> SYSBOOT argument record.
vmb_sections=[
    (1,94,None,None,'DEC license, revision notes, and driver table description'),
    (95,104,'src/vms_vmbargs.c','port_boot_driver_register','CPU and device filters, action and driver size fields'),
    (105,116,'src/vms_vmbargs.c','port_boot_driver_register','driver-relative offsets and entry point field'),
    (117,128,'src/vms_vmbargs.c','port_boot_driver_register','optional driver name, unit initialization, source psect end'),
    (129,133,None,None,'VMB argument layout description'),
    (134,140,'src/vms_vmbargs.h','port_vmb_arguments','argument count and FILEREAD cache descriptor'),
    (141,145,'src/vms_vmbargs.h','port_vmb_arguments','PFN bounds, good-page map, optional microcode, SCS node'),
    (146,149,'src/vms_vmbargs.h','port_vmb_arguments','boot flags, CI bound, flag bit zero'),
    (150,152,'src/vms_vmbargs.c','port_vmb_memory_arguments','native RPB argument count and memory descriptors'),
    (153,155,None,None,'source END directives and final blank line')]
vmb_cov=[]
for first,last,path,symbol,purpose in vmb_sections:
    if path is None:
        vmb_cov.append({'original_lines':[first,last],'status':'excluded','reason':purpose})
    else:
        at=line_for_symbol(path,symbol)
        if at is None:missing+=1
        vmb_cov.append({'original_lines':[first,last],
                        'status':'mapped' if at else 'missing',
                        'pc_file':path,'pc_symbol':symbol,'pc_line':at,
                        'function':purpose})
result['files'].append({'original_file':'BOOTS/SRC/BOOTS.MAR',
    'original_lines':155,'sections':vmb_cov,
    'platform_changes':['VAX driver PSECT symbols become relative PC service table offsets',
                        'native BIOS E820 replaces VAX memory controller discovery'],
    'unresolved_integration':'VMB.MAR and SYSBOOT.MAR machine initialization remain incomplete; SYS.EXE now exists in Files-11 and loads, but INIT/INILOA and system services do not yet run.'})

# SYSINI/SRC/SYSMOU.B32: the complete MOUNT_SYSTEM and MAIN_HANDLER
# sequencing is implemented with explicit service calls. Missing ACP
# service providers stop boot instead of claiming a successful mount.
sysmount_ranges=[
    (1,97,None,None,'source notice, history and BLISS declarations'),
    (98,142,'src/vms_sysmount.c','port_sysmount_reset','mount status and resource storage'),
    (143,180,'src/vms_sysmount.c','port_sysmount_reset','original MOUDEF system disk options, default volume label'),
    (181,238,'src/vms_sysmount.c','port_sysmount_system','system mount arguments and privileged service entry'),
    (239,270,'src/vms_sysmount.c','port_sysmount_system','GETCHN primary/secondary checks, device flags and physical name'),
    (271,296,'src/vms_sysmount.c','port_sysmount_system','home read, ODS mount, ACP and conditional rebuild'),
    (297,350,'src/vms_sysmount.c','port_sysmount_main_handler','condition handler, signal status and mechanism data'),
    (351,362,'src/vms_sysmount.c','port_sysmount_main_handler','severe condition unwind and return status'),
    (363,365,None,None,'BLISS end directives and blank line'),
]
sysmount_sections=[]
for first,last,path,sym,why in sysmount_ranges:
    if path is None:
        sysmount_sections.append({'original_lines':[first,last], 'status':'excluded', 'reason':why})
    else:
        line=line_for_symbol(path,sym)
        if line is None:missing+=1
        sysmount_sections.append({'original_lines':[first,last],
            'status':'mapped' if line else 'missing', 'pc_file':path,
            'pc_symbol':sym,'pc_line':line,'function':why})
result['files'].append({'original_file':'SYSINI/SRC/SYSMOU.B32',
    'original_lines':365,'sections':sysmount_sections,
    'unresolved_integration':'Requires real $GETCHN, mounted volume and F11ACP. Native SYS.EXE and SYSINIT remain incomplete.'})

# BOOTS/SRC/VMB.MAR: only the source-backed RPB sections below are done.
# Memory-controller, console restart and secondary image activation remain missing.
vmb_rpb_ranges=[
    (695,760,'src/vms_vmb_rpb.c','port_vmb_init_restart','boot device, restart settings and initial RPB fields'),
    (774,805,'src/vms_vmb_rpb.c','port_vmb_init_restart','RPB PFN map and early physical-page allocations'),
    (859,877,'src/vms_vmb_rpb.c','port_vmb_init_restart','PFN bounds, memory descriptors and free page counts'),
    (1685,1720,'src/vms_vmb_rpb.c','port_vmb_init_restart','good-page counting from BIOS E820 range map')]
rpb_sections=[]
for first,last,path,sym,why in vmb_rpb_ranges:
    line=line_for_symbol(path,sym)
    if line is None:missing+=1
    rpb_sections.append({'original_lines':[first,last],
       'status':'mapped' if line else 'missing','pc_file':path,
       'pc_symbol':sym,'pc_line':line,'function':why})
# Explicitly list the unimplemented ranges. A mapped RPB function does not
# make VMB.MAR as a whole complete.
current=1
vmb_full_sections=[]
for mapped in rpb_sections:
    first,last=mapped['original_lines']
    if current<first:
        vmb_full_sections.append({'original_lines':[current,first-1],
            'status':'missing','reason':'VMB source routines not yet ported'})
    vmb_full_sections.append(mapped)
    current=last+1
if current<=2402:
    vmb_full_sections.append({'original_lines':[current,2402],
        'status':'missing','reason':'VMB secondary-image transfer and hardware startup still pending'})
result['files'].append({'original_file':'BOOTS/SRC/VMB.MAR',
   'original_lines':2402,'sections':vmb_full_sections,
   'unresolved_integration':'Many VMB routines are not yet implemented, including console restart, complete memory discovery and SYSBOOT transfer.'})

# SYS/SRC/SYSGETTIM.MAR: current system time with calling-mode access
# protection and a retry after a changing quadword is copied.
gettim_ranges=[
    (1,76,None,None,'DEC notice, declarations and service interface'),
    (77,81,'src/vms_exe_gettim.c','port_exe_gettim','get destination and check write permission'),
    (82,82,'src/vms_exe_gettim.c','port_exe_gettim','write a time quadword to the caller buffer'),
    (83,86,'src/vms_exe_gettim.c','port_exe_gettim','verify stable value; retry after concurrent update'),
    (87,88,'src/vms_exe_gettim.c','port_exe_gettim','normal completion or access violation'),
    (89,91,None,None,'end directive and blank lines')]
gettim=[]
for first,last,path,symbol,purpose in gettim_ranges:
    if path is None:
        gettim.append({'original_lines':[first,last],'status':'excluded','reason':purpose})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        gettim.append({'original_lines':[first,last],'status':'mapped' if line else 'missing',
            'pc_file':path,'pc_symbol':symbol,'pc_line':line,'function':purpose})
result['files'].append({'original_file':'SYS/SRC/SYSGETTIM.MAR',
    'original_lines':91,'sections':gettim,
    'platform_changes':['IA-32 32-bit clock stores use a sequence for consistent 64-bit reads',
                        'page-table translation replaces the VAX IFNOWRT access check'],
    'unresolved_integration':'Executive service dispatch and SYS.EXE image activation remain incomplete'})
# SYS/SRC/SYSSETSSF.MAR: all executable source operations are mapped.
ssf_ranges=[
    (1,57,None,None,'DEC notice, service interface and declaration section'),
    (58,62,'src/vms_exe_setssf.c','port_exe_setssf','caller previous-mode test and NOPRIV result'),
    (63,64,'src/vms_exe_setssf.c','port_exe_setssf','filter byte store and NORMAL result'),
    (65,67,None,None,'return/end directive and blank lines')]
ssf=[]
for first,last,path,symbol,purpose in ssf_ranges:
    if path is None:
        ssf.append({'original_lines':[first,last],'status':'excluded','reason':purpose})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        ssf.append({'original_lines':[first,last],'status':'mapped' if line else 'missing',
            'pc_file':path,'pc_symbol':symbol,'pc_line':line,'function':purpose})
result['files'].append({'original_file':'SYS/SRC/SYSSETSSF.MAR',
    'original_lines':67,'sections':ssf,
    'platform_changes':['VAX PSL previous mode is passed from the native IA-32 service trap'],
    'unresolved_integration':'The control-region filter byte needs the native executive service vector'})

# SYS/SRC/SYSSETEXV.MAR: mode checking and exception-vector assignment.
setexv_ranges=[
    (1,81,None,None,'DEC notice and service calling description'),
    (82,86,'src/vms_exe_setexv.c','port_exe_setexv','maximize requested mode with previous access mode'),
    (87,90,'src/vms_exe_setexv.c','port_exe_setexv','primary, secondary and last-chance vector selection'),
    (91,95,'src/vms_exe_setexv.c','port_exe_setexv','optional previous vector result, access violation without a store'),
    (96,98,'src/vms_exe_setexv.c','port_exe_setexv','assign new handler and return normal status'),
    (99,101,None,None,'assembler end and blank lines')]
setexv=[]
for first,last,path,symbol,purpose in setexv_ranges:
    if path is None:
        setexv.append({'original_lines':[first,last],'status':'excluded','reason':purpose})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        setexv.append({'original_lines':[first,last],'status':'mapped' if line else 'missing',
            'pc_file':path,'pc_symbol':symbol,'pc_line':line,'function':purpose})
result['files'].append({'original_file':'SYS/SRC/SYSSETEXV.MAR',
    'original_lines':101,'sections':setexv,
    'platform_changes':['VAX condition-handler vectors become process control-region arrays',
                        'native page-table write checks replace VAX IFNOWRT'],
    'unresolved_integration':'Native executive process control region and service trap dispatch still missing'})


# Full translated service body for SYSGETSYI, including the first and
# final descriptor probes, data conversion, event and AST completion.
def exe_mapped_source(original, total, regions, notes):
    sections=[]
    for first,last,pc_file,pc_symbol,purpose in regions:
        if pc_file is None:
            sections.append({'original_lines':[first,last], 'status':'excluded',
                             'reason':purpose})
            continue
        number=line_for_symbol(pc_file,pc_symbol)
        if number is None:
            raise RuntimeError('Missing native symbol '+str(pc_symbol))
        sections.append({'original_lines':[first,last], 'status':'mapped',
                         'pc_file':pc_file,'pc_symbol':pc_symbol,
                         'pc_line':number,'function':purpose})
    result['files'].append({'original_file':original,'original_lines':total,
                            'sections':sections,'unresolved_integration':notes})

exe_mapped_source('SYS/SRC/SYSGETSYI.MAR',392,[
    (1,87,None,None,'copyright, historical notes and calling sequence'),
    (88,104,'src/vms_exe_getsyi.c','port_exe_getsyi','structure and item limits'),
    (105,167,None,None,'service interface and declarations'),
    (168,176,'src/vms_exe_getsyi.c','port_exe_getsyi','optional IOSB write probe and clear'),
    (177,190,'src/vms_exe_getsyi.c','port_exe_getsyi','event clear and AST quota check'),
    (191,218,'src/vms_exe_getsyi.c','port_exe_getsyi','descriptor walk and write protection'),
    (219,230,'src/vms_exe_getsyi.c','port_exe_getsyi','success and error dispatch'),
    (231,249,'src/vms_exe_getsyi.c','port_exe_getsyi','post event, IOSB and completion AST'),
    (250,292,None,None,'CHECKITEM interface description'),
    (293,303,'src/vms_exe_getsyi.c','port_exe_getsyi','software/hardware item limit checks'),
    (304,346,None,None,'PUTDATA interface description'),
    (347,374,'src/vms_exe_getsyi.c','port_exe_getsyi','8-byte version, CPU type and SID'),
    (375,390,'src/vms_exe_getsyi.c','port_exe_getsyi','MOVC5 zero padding, truncated length and access checks'),
    (391,392,None,None,'assembler terminator')],
    'Actual process event flags and AST dispatch must be installed in SYS.EXE before guest use; hardware SID needs IA-32 startup binding.')

exe_mapped_source('SYS/SRC/VERSION.MAR',53,[
    (1,41,None,None,'copyright notice and declarations'),
    (42,48,'src/vms_exe_version.c','port_exe_announce','original release announcement byte string'),
    (49,50,'src/vms_exe_version.c','port_exe_version_quadword','release version value S1JY'),
    (51,53,None,None,'end directive')],
    'The announcement remains unused until SYS.EXE completes required initialization.')

exe_mapped_source('SYS/SRC/SYSLOAVEC.MAR',240,[
    (1,118,None,None,'license, notes, source switch and macro description'),
    (119,141,'src/vms_sysloavec.c','port_sysloavec_link','typed resident vectors and loadable-image relative offsets'),
    (142,146,None,None,'section labels'),
    (147,163,'src/vms_sysloavec.c','port_sysloavec_link','load image size and 12-byte descriptor validation'),
    (164,169,'src/vms_sysloavec.c','port_sysloavec_init','resident vector table base'),
    (170,176,None,None,'vector list headings'),
    (177,209,'src/vms_sysloavec.c','types','all 23 vector entries in original source order'),
    (210,213,'src/vms_sysloavec.c','port_sysloavec_link','negative vector-list terminator'),
    (214,219,None,None,'unloaded-vector note'),
    (220,223,'src/vms_sysloavec.c','port_sysloavec_unloaded','native processor halt on unresolved entry'),
    (224,228,None,None,'patch area heading'),
    (229,236,'src/vms_sysloavec.c','port_sysloavec_patch_init','fifteen-word patch area'),
    (237,240,None,None,'source terminator')],
    'Actual CPU-specific loadable image and live INIT LINK_VEC handoff are not installed yet.')


exe_mapped_source('SYS/SRC/SYSEVTSRV.MAR',314,[
    (1,117,None,None,'DEC notice and system service calling description'),
    (118,124,'src/vms_exe_event.c','port_exe_clref','clear event system service'),
    (125,155,None,None,'cluster resolution calling interface'),
    (156,180,'src/vms_exe_event.c','port_exe_getefc','local and common cluster selection with slave-to-master path'),
    (181,208,None,None,'internal clear service calling interface'),
    (209,224,'src/vms_exe_event.c','port_exe_clref','interlocked flag clear, old-bit state and errors'),
    (225,254,None,None,'read event service interface'),
    (255,268,'src/vms_exe_event.c','port_exe_readef','entire 32-bit flag mask, destination checks, old-bit status'),
    (269,298,None,None,'set event service interface'),
    (299,310,'src/vms_exe_event.c','port_exe_setef','scheduler post and error-status propagation'),
    (311,314,None,None,'end directive')],
    'SCH$POSTEF must be bound to the live process scheduler for wakeups; SYS.EXE is not executable yet.')


exe_mapped_source('SYS/SRC/SYSSCHEVT.MAR',300,[
    (1,67,None,None,'copyright, history and assembler declarations'),
    (68,80,'src/vms_exe_schevt.c','port_exe_schdwk','source-defined wake and timer argument order'),
    (81,132,None,None,'calling conventions and service descriptions'),
    (133,138,'src/vms_exe_schevt.c','port_exe_schdwk','resolve target PID with caller access checks'),
    (139,154,'src/vms_exe_schevt.c','port_exe_schdwk','repeat delta, sign checks and 10-ms lower bound'),
    (155,163,'src/vms_exe_schevt.c','port_exe_schdwk','time probe, entry allocation and AST quota debit'),
    (164,204,None,None,'SETIMR service description and assembler sections'),
    (205,212,'src/vms_exe_schevt.c','port_exe_setimr','clear and validate selected event flag'),
    (213,234,'src/vms_exe_schevt.c','port_exe_setimr','AST and JIB timer quota, mode, request ID and EF number'),
    (235,245,'src/vms_exe_schevt.c','port_exe_setimr','quota failure and real scheduler resource wait callback'),
    (246,252,None,None,'BUILD TQE description'),
    (253,266,'src/vms_exe_schevt.c','fetch_quad','page-safe eight-byte read and bounded nonpaged entry allocation'),
    (267,287,'src/vms_exe_schevt.c','expiration','absolute/delta time translation and repeated wake validation'),
    (288,297,'src/vms_exe_schevt.c','port_exe_timer_advance','sorted time queue, expiry dispatch, quota return and failures'),
    (298,300,None,None,'assembler ending and blank lines')],
    'Full native timer services are implemented and host tested. The guest must bind '
    'event posting, wakeups, AST delivery and resource waiting to live PCB queues '
    'after SYS.EXE starts; no timer service is reported live before that.')

exe_mapped_source('SYS/SRC/SYSSETMOD.MAR',163,[
    (1,80,None,None,'DEC notice, macros and service calling description'),
    (81,83,'src/vms_exe_setmod.c','port_exe_setrwm','set caller resource wait flag'),
    (84,111,None,None,'failure-mode service description'),
    (112,116,'src/vms_exe_setmod.c','port_exe_setsfm','select previous-mode failure bit'),
    (117,150,None,None,'swap-mode service description'),
    (151,154,'src/vms_exe_setmod.c','port_exe_setswm','check PSWAPM privilege'),
    (155,159,'src/vms_exe_setmod.c','set_mode','old-state return and low-bit insertion'),
    (160,163,None,None,'source ending')],
    'Live process PCB status bits need to bind to this native mode view during '
    'SYS.EXE process creation and service dispatch.')

exe_mapped_source('SYS/SRC/SYSCANEVT.MAR',140,[
    (1,59,None,None,'DEC notice, macros and argument definitions'),
    (60,80,None,None,'cancel-timer service calling description'),
    (81,88,'src/vms_exe_canevt.c','port_exe_cantim',
     'maximum access mode, caller PID, request ID and timer type'),
    (89,126,None,None,'cancel-wakeup service calling description'),
    (127,131,'src/vms_exe_canevt.c','port_exe_canwak',
     'resolve target PID with access and privilege checks'),
    (132,136,'src/vms_exe_canevt.c','remove_matching',
     'remove matching TQE entries, restore quota and report normal'),
    (137,140,None,None,'source ending')],
    'Scheduler timer-IPL exclusion is provided by the caller lock. Guest '
    'process resolution and the executive dispatch still need live bindings.')

exe_mapped_source('SYS/SRC/TIMESCHDL.MAR',423,[
    (1,115,None,None,'source setup and clock interrupt interface'),
    (116,120,'src/vms_exe_gettim.c','port_exe_systime_tick',
     'actual i386 PIT IRQ0 increments the VMS 100-ns quadword by 100000'),
    (121,125,None,None,'clock statistics header')],
    'Only hardware time update from EXE$HWCLKINT is ported so far; process '
    'quantum, timer soft interrupts, accounting, and other ranges 126-423 '
    'are still required. This original source file is not complete.')
# Mark substantive unported TIMESCHDL ranges as missing rather than excluded.
result['files'][-1]['sections'].append({
    'original_lines':[126,423], 'status':'missing',
    'reason':'CPU accounting, quantum expiration, timer software dispatch and related routines are not ported'})

# M83: eleven original executive modules, including scheduler and mode dispatch.
for original,length,ranges,note in [
    ('SYSSETSTK.MAR',114,[(1,89,None,None,'DEC source and stack service interface'),
       (90,112,'vms_exe_setstk','port_exe_setstk','mode selection, old limits and access probes'),
       (113,114,None,None,'assembler end')],
       'Requires live per-process stack limit arrays and caller-mode memory access.'),
    ('SYSSETPRV.MAR',195,[(1,108,None,None,'copyright, history and service interface'),
       (109,136,'vms_exe_setprv','port_exe_setprv','validate flags and return old privilege mask'),
       (137,146,'vms_exe_setprv','port_exe_setprv','service exit statuses'),
       (147,178,'vms_exe_setprv','port_exe_setprv','authorized privilege, image, inner-mode and partial grant'),
       (179,193,'vms_exe_setprv','port_exe_setprv','current, PHD and permanent disable'),
       (194,195,None,None,'assembler end')],
       'Requires PCB/PHD privilege fields and live service dispatch.'),
    ('SYSSETPRI.MAR',177,[(1,129,None,None,'source history and process priority interface'),
       (130,145,'vms_exe_setpri','port_exe_setpri','previous priority access and target process lookup'),
       (146,158,'vms_exe_setpri','port_exe_setpri','authorized priority cap and saved fields'),
       (159,175,'vms_exe_setpri','port_exe_setpri','mutex, ready queue notification and old priority return'),
       (176,177,None,None,'source ending')],
       'Requires live PCB process resolution and scheduler-ready-queue callback.'),
    ('SYSSETPRA.MAR',176,[(1,103,None,None,'source header and power AST interface'),
       (104,125,'vms_exe_setpra','port_exe_setpra','register AST, access mode, quota and pending flag'),
       (126,134,None,None,'power recovery routine description'),
       (135,154,'vms_exe_setpra','port_exe_powerast','visit PCB vector, allocate kernel recovery AST and clear duration'),
       (155,165,None,None,'special AST description'),
       (166,174,'vms_exe_setpra','port_exe_powerast_requeue','convert kernel AST to normal AST'),
       (175,176,None,None,'assembler end')],
       'Physical power-fail handler and actual AST allocator must bind to these routines.'),
    ('SYSADJSTK.MAR',128,[(1,89,None,None,'source header and outer stack interface'),
       (90,100,'vms_exe_adjstk','port_exe_adjstk','outer mode privilege check and new pointer'),
       (101,113,'vms_exe_adjstk','port_exe_adjstk','signed adjustment and 512-byte growth protection'),
       (114,126,'vms_exe_adjstk','port_exe_adjstk','user stack expansion, errors and saved-mode register'),
       (127,128,None,None,'assembler end')],
       'Requires live saved stack pointers and real kernel-mode stack expansion.'),
    ('SYSDERLMB.MAR',136,[(1,113,None,None,'copyright and error-log service interface'),
       (114,134,'vms_exe_derlmb','port_exe_derlmb','DIAGNOSE privilege, synchronized owner and unit release'),
       (135,136,None,None,'assembler end')],
       'Error-log I/O forwarding must consume the declared mailbox descriptor.'),
    ('SYSGETPTI.MAR',332,[(1,131,None,None,'copyright, declarations and memory-service interface'),
       (132,144,'vms_exe_getpti','port_exe_getpti','initialize 512-byte virtual page search and minimum pages'),
       (145,204,None,None,'per-page routine interface and page-class description'),
       (205,281,'vms_exe_getpti','port_exe_getpti','PTE lookup, page ownership, matching run and minimum size'),
       (282,330,'vms_exe_getpti','demand_zero','transition, global and section demand-zero detection'),
       (331,332,None,None,'assembler end')],
       'VMS PTE provider must be bound to the native IA-32 page ownership map.'),
    ('SYSCHGMOD.MAR',132,[(1,103,None,None,'source history and mode service interface'),
       (104,108,'vms_exe_chgmod','port_exe_cmexec','CMEXEC privilege and fallback'),
       (109,130,'vms_exe_chgmod','port_exe_cmkrnl','CMKRNL privilege and native protected CALLG'),
       (131,132,None,None,'assembler end')],
       'Mode executor must perform actual IA-32 privilege and stack change.'),
    ('SYSDCLCMH.MAR',114,[(1,91,None,None,'source history and change-handler interface'),
       (92,103,'vms_exe_dclcmh','port_exe_dclcmh','select supervisor, user or compatibility vector'),
       (104,112,'vms_exe_dclcmh','port_exe_dclcmh','old-vector write, invalid service bugcheck and access checks'),
       (113,114,None,None,'assembler end')],
       'Live exception and compatibility-mode trap dispatch not yet installed.'),
    ('SCHED.MAR',108,[(1,57,None,None,'copyright, source setup and scheduling interface'),
       (58,74,'vms_exe_sched','port_exe_sched_resched','save current process state, enqueue and request next'),
       (75,99,'vms_exe_sched','port_exe_sched_select','highest ready queue, base-priority float and context load'),
       (100,106,'vms_exe_sched','port_exe_sched_select','wait for interrupt when idle and fatal queue error'),
       (107,108,None,None,'assembler end')],
       'Real IA-32 context switch and PCB type mapping require guest binding.'),
    ('NULLPROC.MAR',103,[(1,97,None,None,'copyright and idle process description'),
       (98,101,'vms_exe_nullproc','port_exe_nullproc','native interruptible idle loop'),
       (102,103,None,None,'assembler end')],
       'Idle task must be selected by the live process scheduler.')
]:
    mapped=[]
    for first,last,basename,symbol,reason in ranges:
        if basename is None:
            mapped.append({'original_lines':[first,last],'status':'excluded','reason':reason})
        else:
            path='src/'+basename+'.c'
            line=line_for_symbol(path,symbol)
            mapped.append({'original_lines':[first,last],
                           'status':'mapped' if line else 'missing',
                           'pc_file':path,'pc_symbol':symbol,'pc_line':line,
                           'function':reason})
            if line is None:missing+=1
    result['files'].append({'original_file':'SYS/SRC/'+original,
                            'original_lines':length,'sections':mapped,
                            'unresolved_integration':note})


# M84: twenty source-file mappings. Keep blank and declaration ranges out of functional counts.
for original,total,parts,note in [('SYS/SRC/SYSASTCON.MAR', 188, [(117, 127, 'vms_exe_astcon', 'port_exe_setast'), (166, 186, 'vms_exe_astcon', 'port_exe_dclast')], 'Live AST queue and process quota must be bound before dispatch.'), ('SYS/SRC/SYSWAIT.MAR', 353, [(123, 160, 'vms_exe_wait', 'port_exe_wfland'), (161, 200, 'vms_exe_wait', 'port_exe_wflor'), (201, 254, 'vms_exe_wait', 'port_exe_waitfr'), (255, 352, 'vms_exe_wait', 'wait_common')], 'Actual context switch and wait queue wakeup need the resident scheduler.'), ('SYS/SRC/SYSDCLEXH.MAR', 159, [(81, 97, 'vms_exe_dclexh', 'port_exe_canexh'), (125, 136, 'vms_exe_dclexh', 'port_exe_dclexh'), (144, 155, 'vms_exe_dclexh', 'choose')], 'Per-mode termination lists must be bound to each PCB.'), ('SYS/SRC/SYSEXIT.MAR', 149, [(101, 145, 'vms_exe_exit', 'port_exe_exit')], 'Rundown and actual process deletion need native process manager binding.'), ('SYS/SRC/SYSFORCEX.MAR', 140, [(107, 124, 'vms_exe_forcex', 'port_exe_forcex'), (133, 139, 'vms_exe_forcex', 'port_exe_forcex_deliver')], 'Pending forced-exit AST requires native delivery.'), ('SYS/SRC/SYSSETIME.MAR', 511, [(124, 148, 'vms_exe_setime', 'port_exe_setime'), (188, 223, 'vms_exe_setime', 'port_exe_setime'), (224, 303, 'vms_exe_setime', 'year_for'), (304, 403, 'vms_exe_setime', 'port_exe_setime'), (404, 451, 'vms_exe_setime', 'port_exe_setime'), (469, 509, 'vms_exe_setime', 'port_exe_setime')], 'RTC, clock ownership, timer queue and SYS.EXE SYSPARAM persistent writes need live callbacks.'), ('SYS/SRC/SYSCANCEL.MAR', 242, [(127, 138, 'vms_exe_cancel', 'port_exe_canceln'), (139, 241, 'vms_exe_cancel', 'port_exe_cancel')], 'Actual driver cancel and ACP request queues remain unbound.'), ('SYS/SRC/SYSDASSGN.MAR', 204, [(109, 203, 'vms_exe_dassgn', 'port_exe_dassgn')], 'Driver cancellation, channel and mount state require native I/O database binding.'), ('SYS/SRC/SYSDEVALC.MAR', 384, [(171, 248, 'vms_exe_devalc', 'port_exe_alloc'), (298, 338, 'vms_exe_devalc', 'port_exe_dalloc'), (339, 382, 'vms_exe_devalc', 'release_one')], 'Native DDB/UCB and driver callbacks must bind to executive I/O database.'), ('SYS/SRC/SYSPURGWS.MAR', 354, [(122, 192, 'vms_exe_purgws', 'port_exe_purgws'), (193, 262, 'vms_exe_purgws', 'port_exe_purgws_scan'), (263, 353, 'vms_exe_purgws', 'port_exe_purgws_scan')], 'Live page-table/WSL ownership, pagefile and unmap callbacks needed.'), ('SYS/SRC/SYSADJWSL.MAR', 422, [(151, 245, 'vms_exe_adjwsl', 'port_exe_adjwsl'), (246, 306, 'vms_exe_adjwsl', 'port_exe_wspchk'), (307, 400, 'vms_exe_adjwsl', 'port_exe_adjwsl'), (401, 421, 'vms_exe_adjwsl', 'port_exe_extra_dyn_ws')], 'Native process working-set, PHD growth and page reclaim need memory manager integration.'), ('SYS/SRC/SYSSETPRT.MAR', 409, [(151, 243, 'vms_exe_setprt', 'port_exe_setprt'), (244, 408, 'vms_exe_setprt', 'adjust_one')], 'Real system PTE and copy-on-reference pagefile ownership must be wired.'), ('SYS/SRC/CONSOLIO.MAR', 280, [(75, 90, 'vms_exe_consolio', 'port_exe_outhex'), (112, 135, 'vms_exe_consolio', 'port_exe_outhex'), (136, 158, 'vms_exe_consolio', 'port_exe_outblank'), (159, 222, 'vms_exe_consolio', 'port_exe_outchar'), (223, 248, 'vms_exe_consolio', 'port_exe_outcrlf'), (249, 269, 'vms_exe_consolio', 'port_exe_outcstring'), (270, 279, 'vms_exe_consolio', 'port_exe_outzstring')], 'Native serial register implementation must bind output hooks to hardware.'), ('SYS/SRC/SCBVECTOR.MAR', 164, [(69, 71, 'vms_exe_scbvector', 'port_exe_scb_init'), (73, 161, 'vms_exe_scbvector', 'port_exe_scb_init')], 'Original vector order and stack designation mapped; PC IDT targets not all installed. Unmapped VAX-only nexus hardware vectors have no PC counterpart.'), ('BOOTS/SRC/ACTIMAGE.MAR', 139, [(105, 138, 'vms_boo_actimage', 'port_boo_actimage')], 'Native image activator and process rundown must bind to actual image loader.'), ('BOOTS/SRC/READLBN.MAR', 179, [(105, 114, 'vms_rtf_readlbn', 'port_rtf_target_dev'), (115, 156, 'vms_rtf_readlbn', 'port_rtf_target_dev'), (157, 178, 'vms_rtf_readlbn', 'port_rtf_read_lbn')], 'VMS QIOW device channel and RT-11 filesystem mount binding pending.'), ('BOOTS/SRC/READDRIV.MAR', 176, [(79, 94, 'vms_iogen_readdriv', 'port_iogen_readdriv'), (139, 175, 'vms_iogen_readdriv', 'port_iogen_readdriv')], 'Real RMS OPEN and section mapping must bind to native image loader.'), ('BOOTS/SRC/CONIO.MAR', 202, [(115, 201, 'vms_boo_conio', 'port_boo_conio_prompt')], 'Real serial I/O hooks not yet connected to standalone SYSBOOT.'), ('BOOTS/SRC/READPRMPT.MAR', 186, [(68, 85, 'vms_boo_readprompt', 'port_boo_readprompt'), (120, 169, 'vms_boo_readprompt', 'port_boo_readprompt'), (170, 185, 'vms_boo_readprompt', 'port_boo_output_line')], 'System terminal assignment and QIOW must bind to resident I/O stack.'), ('BOOTS/SRC/SYSGENMN.MAR', 137, [(96, 112, 'vms_boo_sysgenmn', 'port_boo_sysgen_start'), (123, 136, 'vms_boo_sysgenmn', 'port_boo_sysgen_puterror')], 'Actual SYSGEN utility CLI, system parameters and message writer still need native binding.')]:
    if original=='BOOTS/SRC/READPRMPT.MAR':
        continue  # Existing SYSBOOT entry maps this complete source file.
    regions=[]
    next_line=1
    for first,last,name,symbol in parts:
        if first>next_line:
            regions.append((next_line,first-1,None,None,'DEC header, descriptions or assembler declarations'))
        regions.append((first,last,'src/'+name+'.c',symbol,'native functional counterpart to original section'))
        next_line=last+1
    if next_line<=total:
        regions.append((next_line,total,None,None,'ending directives and nonfunctional text'))
    exe_mapped_source(original,total,regions,note)


# Native TU58 media access and SYSGEN device database display.
exe_mapped_source('BOOTS/SRC/T58BOOTIO.MAR',99,[
    (1,79,None,None,'copyright, VAX ROM interface and declarations'),
    (80,98,'src/vms_boo_t58bootio.c','port_t58_read_lbn',
     'original TU58 unit-zero logical block read through native physical driver'),
    (99,99,None,None,'assembler end')],
    'A physical TU58 serial drive must exist for its native block driver to be bound; VAX ROM entry is excluded.')
exe_mapped_source('BOOTS/SRC/SHODEV.MAR',255,[
    (1,59,None,None,'copyright and revision history'),
    (60,254,'src/vms_boo_shodev.c','port_boo_shodev',
     'SYSGEN SHOW/DRIVER and SHOW/DEVICE database walk and formatting'),
    (255,255,None,None,'assembler end')],
    'Real device database pointers and RIO$OUTPUT_LINE need native SYSGEN binding.')


exe_mapped_source('LOGIN/SRC/PROTCLI.MAR',151,[
    (1,75,None,None,'original notice and CLI protection interface'),
    (76,120,'src/vms_lgi_protcli.c','port_lgi_protect_cli',
     'supervisor ownership, write limits and page-table invalidation'),
    (121,141,None,None,'image activation service calling description'),
    (142,149,'src/vms_lgi_protcli.c','port_lgi_execute_image',
     'rundown user process and transfer to the selected image'),
    (150,151,None,None,'assembler end')],
    'Live LOGINOUT mappings, TLB, and EXE$PROCIMGACT transfer still require guest linkage.')

# M85: original runtime library services and SYS file-name, I/O and fork modules.
for original,total,first,last,path,symbol,note in [
    ('RTL/SRC/LIBANASTR.MAR',224,127,222,'src/vms_rtl85.c','port_lib_analyze_sdesc','Supported VMS descriptors; guest pointer conversion remains to bind.'),
    ('RTL/SRC/LIBEXTZV.MAR',123,115,121,'src/vms_rtl85.c','port_lib_extzv','Reserved operand maps to error until guest exception delivery is attached.'),
    ('RTL/SRC/LIBEXTV.MAR',123,117,121,'src/vms_rtl85.c','port_lib_extv','Reserved operand maps to error until guest exception delivery is attached.'),
    ('RTL/SRC/LIBINSV.MAR',123,117,121,'src/vms_rtl85.c','port_lib_insv','Guest reserved-operand exception is not attached.'),
    ('RTL/SRC/LIBMOVC3.MAR',132,122,130,'src/vms_rtl85.c','port_lib_movc3','Native byte copy.'),
    ('RTL/SRC/LIBMOVC5.MAR',143,131,141,'src/vms_rtl85.c','port_lib_movc5','Native byte copy and fill.'),
    ('RTL/SRC/LIBFFS.MAR',143,133,141,'src/vms_rtl85.c','port_lib_ffs','VMS bit-scan and not-found status.'),
    ('RTL/SRC/LIBFFC.MAR',143,133,141,'src/vms_rtl85.c','port_lib_ffc','VMS bit-scan and not-found status.'),
    ('RTL/SRC/LIBICHAR.MAR',158,137,156,'src/vms_rtl85.c','port_lib_ichar','First character through decoded string descriptor.'),
    ('RTL/SRC/LIBLEN.MAR',147,136,145,'src/vms_rtl85.c','port_lib_len','String descriptor length.'),
    ('RTL/SRC/LIBSKPC.MAR',164,129,162,'src/vms_rtl85.c','port_lib_skpc','First unequal character position.'),
    ('RTL/SRC/LIBLOCC.MAR',165,128,163,'src/vms_rtl85.c','port_lib_locc','First equal character position.'),
    ('RTL/SRC/LIBSPANC.MAR',164,135,162,'src/vms_rtl85.c','port_lib_spanc','Table and mask scan until zero.'),
    ('RTL/SRC/LIBSCANC.MAR',162,135,160,'src/vms_rtl85.c','port_lib_scanc','Table and mask scan until nonzero.'),
    ('RTL/SRC/LIBINDEX.MAR',204,144,201,'src/vms_rtl85.c','port_lib_index','Find substring position.'),
    ('RTL/SRC/LIBMATCHC.MAR',191,137,189,'src/vms_rtl85.c','port_lib_matchc','Find substring position with swapped args.'),
    ('RTL/SRC/LIBABUPCA.MAR',108,90,105,'src/vms_rtl85_tables.c','port_lib_ab_upcase','All 256 ASCII uppercase table bytes.'),
    ('RTL/SRC/LIBCVTUO.MAR',106,101,104,'src/vms_rtl85_tables.c','port_lib_ab_cvt_u_o','20 overpunch characters.'),
    ('RTL/SRC/LIBCVTOU.MAR',135,100,132,'src/vms_rtl85_tables.c','port_lib_ab_cvt_o_u','256-element overpunch-to-digit conversion table.'),
    ('RTL/SRC/LIBCVTPTU.MAR',132,97,129,'src/vms_rtl85_tables.c','port_lib_ab_cvtpt_u','Original 256-byte decimal conversion table.'),
    ('RTL/SRC/LIBCVTTPU.MAR',133,98,130,'src/vms_rtl85_tables.c','port_lib_ab_cvttp_u','Original 256-byte decimal conversion table.'),
    ('RTL/SRC/LIBCVTPTO.MAR',132,97,129,'src/vms_rtl85_tables.c','port_lib_ab_cvtpt_o','Original 256-byte decimal conversion table.'),
    ('RTL/SRC/LIBCVTTPO.MAR',133,98,130,'src/vms_rtl85_tables.c','port_lib_ab_cvttp_o','Original 256-byte decimal conversion table.'),
    ('RTL/SRC/LIBCVTPTZ.MAR',138,102,136,'src/vms_rtl85_tables.c','port_lib_ab_cvtpt_z','Original 256-byte decimal conversion table.'),
    ('RTL/SRC/LIBCVTTPZ.MAR',139,103,137,'src/vms_rtl85_tables.c','port_lib_ab_cvttp_z','Original 256-byte decimal conversion table.'),
    ('SYS/SRC/CVTATB.MAR',176,114,169,'src/vms_rtl85.c','port_sys_cvt_dtb','The three numeric conversion entry points are port_sys_cvt_dtb, port_sys_cvt_otb and port_sys_cvt_htb.'),
    ('SYS/SRC/NLDRIVER.MAR',136,49,133,'src/vms_sys85.c','port_nl_driver_io','Driver completion callback and native DPT registration require I/O database binding.'),
    ('SYS/SRC/RMSRESET.MAR',155,121,151,'src/vms_sys85.c','port_rm_reset','RMS impure data reset requires per-process RMS data to be bound.'),
    ('SYS/SRC/MTFDT.MAR',93,81,90,'src/vms_sys85.c','port_mt_check_access','Device and access-rights callbacks need native I/O database binding.'),
    ('SYS/SRC/CVTFILNAM.MAR',319,137,317,'src/vms_sys85.c','port_fil_cvtfilnam','Files-11 RAD50 word format and version conversion.'),
    ('SYS/SRC/FORKCNTRL.MAR',208,86,205,'src/vms_sys85.c','port_exe_fork','Software interrupt dispatcher and UCB callbacks require kernel interrupt binding.')
]:
    exe_mapped_source(original,total,[
        (1,first-1,None,None,'Original license notice, declarations, and interface text'),
        (first,last,path,symbol,'Native functional equivalent'),
        (last+1,total,None,None,'Assembler termination or blank lines')
    ],note)

exe_mapped_source('SYS/SRC/SVAPTE.MAR',247,[
    (1,122,None,None,'DEC license, page-table layout and interface text'),
    (123,198,'src/vms_exe_memory85.c','port_mmg_svaptechk','native IA-32 system PTE reference and bounds'),
    (199,220,'src/vms_exe_memory85.c','port_mmg_pteadrchk','native validated PTE address'),
    (221,243,'src/vms_exe_memory85.c','port_mmg_pteindex','process and system region boundaries'),
    (244,247,None,None,'assembler end')],
    'Guest page-fault handler must implement nonresident page-table recovery and fatal callback.')
exe_mapped_source('SYS/SRC/BUFFERCTL.MAR',245,[
    (1,80,None,None,'DEC license, declarations and IO buffer interface'),
    (81,114,'src/vms_exe_memory85.c','port_ioc_getbyte','single byte with mapped-page crossing'),
    (115,139,'src/vms_exe_memory85.c','port_ioc_putbyte','single byte write with mapped-page crossing'),
    (140,163,'src/vms_exe_memory85.c','port_ioc_initbufwind','window initialization'),
    (164,196,'src/vms_exe_memory85.c','port_ioc_movfruser','copy from checked user memory'),
    (197,228,'src/vms_exe_memory85.c','port_ioc_movtouser','copy into checked user memory'),
    (229,242,'src/vms_exe_memory85.c','port_ioc_filspt','native IA-32 PTE lookup and page window'),
    (243,245,None,None,'assembler end')],
    'Device UCB and physical memory callbacks must be bound to native I/O driver.')

exe_mapped_source('SYS/SRC/DEBUGDATA.MAR',52,[
    (1,34,None,None,'DEC license and processor register data description'),
    (35,49,'src/vms_exe_image_end85.c','port_bug_debug','512-byte bugcheck register store and IA-32 alignment'),
    (50,52,None,None,'assembler end')],
    'Native bugcheck exception handler must save the IA-32 trap frame to these slots.')
exe_mapped_source('SYS/SRC/MDATEND.MAR',102,[
    (1,84,None,None,'DEC license, history and memory manager data layout'),
    (85,90,'src/vms_exe_image_end85.c','port_mmg_pfn_patch','16 six-byte PFN opcode patch slots and zero termination'),
    (91,96,'src/vms_exe_image_end85.c','port_mmg_pfn_patch_desc','PFN fixup patch descriptor'),
    (97,100,'src/vms_exe_image_end85.c','port_mmg_sys_end','page-aligned system image end marker'),
    (101,102,None,None,'assembler end')],
    'The final SYS.EXE link script must place .vms_sys_end after every resident section.')


# M86: entire ODS-1 and ODS-2 file-control routines. Shared code is mapped
# to each original implementation; each different structure-level path is kept.
f11_86_files = [
    ('F11A/SRC/CHKSUM.B32',125,60,121,'port_f11a_checksum'),
    ('F11B/SRC/CHKSUM.B32',124,59,120,'port_f11b_checksum'),
    ('F11A/SRC/CPYNAM.B32',120,62,116,'port_f11a_copy_name'),
    ('F11B/SRC/CPYNAM.B32',119,61,115,'port_f11b_copy_name'),
    ('F11B/SRC/FILESIZE.B32',129,58,125,'port_f11b_file_size'),
    ('F11A/SRC/GETTIM.B32',174,66,170,'port_f11a_get_time'),
    ('F11B/SRC/GETTIM.B32',153,60,149,'port_f11b_get_time'),
    ('F11B/SRC/GETPTR.B32',152,67,148,'port_f11b_get_map_pointer'),
    ('F11B/SRC/GETRVN.B32',186,66,182,'port_f11b_apply_rvn'),
    ('F11B/SRC/MATCHNAME.MAR',145,95,142,'port_f11b_match_name'),
    ('F11A/SRC/BADSCN.B32',99,62,95,'port_f11a_scan_badlog'),
    ('F11A/SRC/RETDIR.B32',126,62,122,'port_f11a_return_dir'),
    ('F11B/SRC/RETDIR.B32',151,65,147,'port_f11b_return_dir'),
    ('F11A/SRC/LOCKDB.MAR',132,84,127,'port_f11a_lock_iodb'),
    ('F11B/SRC/LOCKDB.MAR',134,86,129,'port_f11b_lock_iodb'),
    ('F11A/SRC/GETACC.MAR',108,92,103,'port_f11a_get_access'),
    ('F11B/SRC/GETACC.MAR',108,92,103,'port_f11b_get_access'),
    ('F11A/SRC/REQUEU.MAR',115,98,110,'port_f11a_requeue'),
    ('F11B/SRC/REQUEU.MAR',121,103,116,'port_f11b_requeue'),
    ('F11A/SRC/MPWIND.MAR',130,105,125,'port_f11a_map_window'),
    ('F11B/SRC/MPWIND.MAR',139,113,134,'port_f11b_map_window'),
    ('F11A/SRC/NXTHDR.B32',157,61,153,'port_f11a_next_header'),
    ('F11B/SRC/NXTHDR.B32',160,60,156,'port_f11b_next_header'),
]
for orig,total,first,last,sym in f11_86_files:
    integration = ('Native Files-11 ACP process, file-control and disk driver links '
                   'are not yet active in the guest. The original source is '
                   'ported; callbacks must be attached to the live executive.')
    exe_mapped_source(orig,total,[
        (1,first-1,None,None,'Original notices, type definitions and routine description'),
        (first,last,'src/vms_f11_acp86.c',sym,'Native ODS-1/ODS-2 routine'),
        (last+1,total,None,None,'Original module terminator or blank source')
    ],integration)

# M87: original ODS-1 and ODS-2 ACP file-header, FCB, and I/O paths.
# The structures and callbacks are in the IA-32 Files-11 ACP source.
f11_87_files = [
    ('F11A/SRC/MOUNT.B32',167,65,163,'port_f11a_mount'),
    ('F11B/SRC/MOUNT.B32',166,64,162,'port_f11b_mount'),
    ('F11A/SRC/SCHFCB.B32',145,63,141,'port_f11a_search_fcb'),
    ('F11B/SRC/SCHFCB.B32',146,63,142,'port_f11b_search_fcb'),
    ('F11A/SRC/MAKSTR.B32',174,63,170,'port_f11a_make_string'),
    ('F11B/SRC/MAKSTR.B32',174,63,170,'port_f11b_make_string'),
    ('F11A/SRC/CHKHDR.B32',173,63,169,'port_f11a_check_header'),
    ('F11B/SRC/CHKHD2.B32',184,70,180,'port_f11b_check_header2'),
    ('F11A/SRC/INIFCB.B32',158,63,154,'port_f11a_init_fcb'),
    ('F11B/SRC/INIFC2.B32',260,71,256,'port_f11b_init_fcb2'),
    ('F11A/SRC/CREFCB.B32',217,68,213,'port_f11a_create_fcb'),
    ('F11B/SRC/CREFCB.B32',182,70,178,'port_f11b_create_fcb'),
    ('F11B/SRC/MAKPTR.B32',274,80,270,'port_f11b_make_pointer'),
    ('F11A/SRC/RDHEDR.B32',177,66,173,'port_f11a_read_header'),
    ('F11B/SRC/RDHEDR.B32',200,72,196,'port_f11b_read_header'),
    ('F11A/SRC/CREWIN.B32',168,66,164,'port_f11a_create_window'),
    ('F11B/SRC/CREWIN.B32',169,65,165,'port_f11b_create_window'),
    ('F11A/SRC/GETFIB.B32',188,60,184,'port_f11a_get_fib'),
    ('F11B/SRC/GETFIB.B32',242,66,238,'port_f11b_get_fib'),
    ('F11A/SRC/MAKACC.B32',198,64,194,'port_f11a_make_access'),
    ('F11B/SRC/MAKACC.B32',194,64,190,'port_f11b_make_access'),
    ('F11A/SRC/IODONE.MAR',149,100,144,'port_f11a_io_done'),
    ('F11B/SRC/IODONE.MAR',150,100,145,'port_f11b_io_done'),
]
for orig,total,first,last,symbol in f11_87_files:
    regions=[(1,first-1,None,None,'Original notices, definitions and procedure description')]
    if orig == 'F11B/SRC/INIFC2.B32':
        regions.extend([
            (71,142,'src/vms_f11_acp87.c','port_f11b_init_fcb2','File-size and FCB setup'),
            (143,256,'src/vms_f11_acp87.c','port_f11b_fill_fcb','FCB attribute refresh')])
    elif orig == 'F11A/SRC/CREFCB.B32':
        regions.extend([
            (68,123,'src/vms_f11_acp87.c','port_f11a_create_fcb','New FCB'),
            (124,213,'src/vms_f11_acp87.c','port_f11a_update_fcb','FCB attribute refresh')])
    elif orig == 'F11B/SRC/CREFCB.B32':
        regions.extend([
            (70,125,'src/vms_f11_acp87.c','port_f11b_create_fcb','New FCB'),
            (126,178,'src/vms_f11_acp87.c','port_f11b_update_fcb','FCB attribute refresh')])
    else:
        regions.append((first,last,'src/vms_f11_acp87.c',symbol,
                        'Native Files-11 ACP routine'))
    regions.append((last+1,total,None,None,'Original module end and blank lines'))
    exe_mapped_source(orig,total,regions,
        'Guest ACP process and disk scheduler must attach the real memory and I/O callbacks.')

# M89: INILOA/INITADP port is partial. The VAX-specific nexus and UNIBUS
# register programming cannot execute on IA-32 and is not counted as
# functional coverage. The source-derived adapter tables and RPB update
# have a tested native counterpart, but no guest INIT caller exists yet.
ini_ranges=[
    (1,450,None,None,'VAX CPU-specific SBI nexus descriptors, history and declarations', 'hardware-excluded'),
    (451,605,'src/vms_iniloa_iomap.c','port_ini_iomap','Native IA-32 I/O-port adapter enumeration, CONFREG/SBICONF and boot RPB outputs','partial'),
    (606,639,None,None,'VAX 512-byte SPTE mapping and VAX console halt','hardware-excluded'),
    (640,909,None,None,'VAX UNIBUS adapter I/O address-space mapping, vector and data setup','hardware-excluded'),
    (910,1053,None,None,'VAX MPM, CI, DR32, MBA adapter hardware initialization','hardware-excluded')
]
segs=[]
for first,last,path,symbol,why,status in ini_ranges:
    if not path:
        segs.append({'original_lines':[first,last], 'status':status, 'reason':why})
    else:
        line=line_for_symbol(path,symbol)
        if line is None:missing+=1
        segs.append({'original_lines':[first,last],
            'status':status if line else 'missing',
            'pc_file':path,'pc_symbol':symbol,'pc_line':line,'function':why})
result['files'].append({'original_file':'INILOA/SRC/INITADP.MAR',
    'original_lines':1053,'sections':segs,
    'platform_changes':['VAX SBI nexus and UNIBUS space have no IA-32 hardware counterpart',
      'IA-32 I/O-port mapper performs explicit discovered device probing',
      'Original boot RPB fields and adapter-type array outputs are retained'],
    'unresolved_integration':'INI$IOMAP has not been called in guest; original VAX-specific initialization branches are excluded only for physically absent VAX hardware; true IA-32 adapter startup and INIT call remain incomplete.'})

(ROOT / 'source-coverage.json').write_text(json.dumps(result, indent=2) + '\n')
print('Source ranges:',sum(len(x.get('sections',[])) for x in result['files']),'; missing mapped functions:',missing)
raise SystemExit(1 if missing else 0)
