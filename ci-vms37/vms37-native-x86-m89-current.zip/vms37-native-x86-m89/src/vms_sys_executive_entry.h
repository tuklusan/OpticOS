#ifndef VMS_SYS_EXECUTIVE_ENTRY_H
#define VMS_SYS_EXECUTIVE_ENTRY_H
#include <stdint.h>
/* SYS.EXE entry handshake.  BOO/INIT must have loaded INILOA and all
 * dependencies before this entry may initialize resident executive state. */
enum { PORT_SYS_EXEC_SIGNATURE=0x37334d56u,PORT_SYS_EXEC_VERSION=1u,
       PORT_SYS_EXEC_NORMAL=1u,PORT_SYS_EXEC_BAD_PARAMETERS=2u };
struct port_sys_exec_start {
    uint32_t signature,version;
    uint64_t system_time;
    uint8_t pcb_type;
    uint8_t initialized_images;
    uint16_t reserved;
};
uint32_t port_sys_executive_entry(const struct port_sys_exec_start *parameters);
#endif
