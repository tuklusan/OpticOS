#include "vms_sysboot_map.h"
uint32_t port_sysboot_mapvbn(const struct port_f11_extent *map,
                              uint32_t count,uint32_t vbn,
                              uint32_t *lbn,uint32_t *remaining,
                              uint32_t *next_index) {
    if(!map||!vbn||!lbn||!remaining||!next_index)
        return PORT_F11_HOME_BADARG;
    for(uint32_t index=0;index<count;index++){
        uint32_t size=map[index].blocks;
        if(!size || map[index].lbn+size<map[index].lbn)
            return PORT_F11_FILE_BAD_MAP;
        if(vbn<=size){
            uint32_t delta=vbn-1u;
            *lbn=map[index].lbn+delta;
            *remaining=size-delta;
            *next_index=index+1u;
            return PORT_F11_HOME_OK;
        }
        vbn-=size;
    }
    *lbn=*remaining=0u;
    *next_index=count;
    return PORT_F11_FILE_EOF;
}
uint32_t port_sysboot_setmap(const struct port_f11_extent *map,
                             uint32_t count,uint32_t first_vbn,
                             uint32_t requested,
                             struct port_f11_extent *result,
                             uint32_t capacity,uint32_t *used) {
    if(!map||!result||!capacity||!used||!first_vbn||!requested)
        return PORT_F11_HOME_BADARG;
    uint32_t lbn=0,remaining=0,next=0;
    uint32_t rc=port_sysboot_mapvbn(map,count,first_vbn,
                                      &lbn,&remaining,&next);
    if(rc!=PORT_F11_HOME_OK)return rc;
    *used=0u;
    while(requested){
        if(*used==capacity)return PORT_F11_FILE_BAD_MAP;
        uint32_t length=remaining<requested?remaining:requested;
        result[*used].blocks=length;
        result[*used].lbn=lbn;
        ++*used;requested-=length;
        if(!requested)break;
        if(next>=count)return PORT_F11_FILE_EOF;
        if(!map[next].blocks ||
           map[next].lbn+map[next].blocks<map[next].lbn)
            return PORT_F11_FILE_BAD_MAP;
        lbn=map[next].lbn;remaining=map[next].blocks;next++;
    }
    return PORT_F11_HOME_OK;
}
