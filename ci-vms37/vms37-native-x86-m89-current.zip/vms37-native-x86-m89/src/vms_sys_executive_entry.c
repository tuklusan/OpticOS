#include "vms_sys_executive_entry.h"
#include "vms_exe_sched.h"
#include "vms_exe_scbvector.h"
#include "vms_exe_gettim.h"
/* Resident SYS.EXE data. Never share these with the earlier boot monitor. */
static struct port_exe_scheduler executive_scheduler;
static struct port_exe_scb_slot executive_scb[PORT_SCB_ENTRIES];
static struct port_exe_systime executive_clock;
/* The source's INIT sequencing cannot be skipped. Until INILOA is loaded
 * and mapped, SYS.EXE refuses to start, rather than faking a boot. */
uint32_t port_sys_executive_entry(const struct port_sys_exec_start *p){
    if(!p || p->signature!=PORT_SYS_EXEC_SIGNATURE ||
       p->version!=PORT_SYS_EXEC_VERSION || !p->initialized_images ||
       !p->pcb_type)return PORT_SYS_EXEC_BAD_PARAMETERS;
    port_exe_sched_init(&executive_scheduler,p->pcb_type);
    port_exe_scb_init(executive_scb);
    port_exe_systime_store(&executive_clock,p->system_time);
    return PORT_SYS_EXEC_NORMAL;
}
