#ifndef VMS_SYSBOOT_MAP_H
#define VMS_SYSBOOT_MAP_H
#include <stdint.h>
#include "vms_boot_files11.h"
/* BOO$MAPVBN and BOO$SETMAP, SYSBOOT.MAR. One-origin file VBNs.
 * Extents use the original normalized count/LBN representation. */
uint32_t port_sysboot_mapvbn(const struct port_f11_extent *map,
                              uint32_t count,uint32_t vbn,
                              uint32_t *lbn,uint32_t *remaining,
                              uint32_t *next_index);
uint32_t port_sysboot_setmap(const struct port_f11_extent *map,
                             uint32_t count,uint32_t first_vbn,
                             uint32_t requested,
                             struct port_f11_extent *result,
                             uint32_t capacity,uint32_t *used);
#endif
