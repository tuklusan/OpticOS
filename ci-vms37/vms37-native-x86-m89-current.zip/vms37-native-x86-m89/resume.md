# Native VAX/VMS 3.7 IA-32 port — M89

Restore `vms37-native-x86-m89-current.zip` into a working directory.
Original source reference: `calmsacibis995/vms37-src`, revision
`2f5bd967bc163bdb4aa9a5e4b1f9981d9995e752`.
No restricted DEC originals are included in this archive.

## Current native implementation

- SYS.EXE remains an independently linked and incomplete native IA-32 image.
  SYSBOOT reads it as a real Files-11 file (FID 11) into reserved RAM.
- Created a separate, source-derived INILOA.EXE (FID 12) containing
  `INI$IOMAP`'s native IA-32 adapter table, CONFREG, SBICONF and boot RPB
  update counterpart. VAX SBI, UNIBUS, MBA and CI hardware paths are
  recorded as hardware-specific exclusions; the actual IA-32 driver
  callbacks are **not yet wired to guest INIT**.
- Extended INDEXF.SYS by an additional mapped cluster (a genuine second
  extent), instead of overwriting BITMAP.SYS. Installed INILOA with a
  checksum-valid header and a sorted directory record. Host tests read both
  images through the original Files-11 VBN and file-ID lookup services.
- The bootstrap now loads both IA-32 ELF32 images independently into
  supervisor physical windows 0x320000..0x37ffff and 0x380000..0x3dffff.
  Strict segment and file validation occurs before executable RAM writes.
- The next expected stop is **unfinished source-ordered INIT sequencing**:
  SYSPARAM data, driver registration, resident executive calls and actual
  adapter initialization are not ready. There is no fake login or DCL.

## Checks

Passed locally: `make all bootcheck imagecheck files1186check
files1187check sysnativecheck iniloacheck`, generation of source-coverage.json
(167 original files, 878 source ranges, zero missing referenced symbols),
source inventory checks, ASan/UBSan host tests for both real ODS-2 images,
IA-32 adapter mappings and RPB output, ELF32 stage-2 and kernel layout.
The INILOA adapter mapping is **partial**; 167 source entries are not 167
complete ports.

No local QEMU system executable is installed. Until a remote single-runner
QEMU transcript confirms the two image loads, **M89 guest execution is not
verified**. Last confirmed QEMU run was M81 (stopped at missing SYS.EXE):
https://github.com/tuklusan/OpticOS/actions/runs/44471312310

## Remaining exit conditions

Both are **false**: not all original lines have full functional native PC
coverage or justified exclusions, and no QEMU boot has proved SYSTEM login,
DCL, real DECnet Phase IV SET HOST 0, second DCL and return via LOGOUT.
Do not equate the partial images or the host tests with a booted VMS.

## Next work

Run `tools/qemu_sysboot_m89.py` in the one existing serialized QEMU CI runner.
Implement source-ordered SYS.EXE INIT, SYSPARAM, PCI/ISA adapter discovery,
real guest driver and scheduler connections, native Files-11 ACP process,
LOGINOUT, DCL and DECnet Phase IV; retest the complete chain in QEMU.
