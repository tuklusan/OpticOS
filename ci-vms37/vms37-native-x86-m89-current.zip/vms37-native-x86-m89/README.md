# VAX/VMS 3.7 native IA-32 port — M88

Source reference: `calmsacibis995/vms37-src`, revision
`2f5bd967bc163bdb4aa9a5e4b1f9981d9995e752`.
Original DEC source is **not** included in this archive.

M88 builds a **separately linked, incomplete native SYS.EXE** at `build/sys.exe`.
The machine-specific VAX image records become static IA-32 ELF32 PT_LOAD
records. It contains the existing native executive service objects and an
entry gated on successful prior INIT image loading. It is neither the complete
original executive nor a stub to bypass initialization.

`tools/install_sys_image.c` installs that ELF32 image through a real ODS-2
Files-11 file (FID 11) in `[SYSEXE]SYS.EXE;1`, with a valid file header,
INDEXF allocation bit, volume cluster allocation bits, directory entry,
physical data blocks, and reread byte-by-byte verification. `kernel.c` now
uses its real IDE BOO driver and F11 VBN reader to load, validate, copy and
clear the executable's memory segments at 0x320000..0x380000, outside the
native physical page allocator. Invalid ELF or missing disk blocks stop boot.

The next required file, `INILOA.EXE`, is still absent. SYSBOOT stops
with its missing-file diagnostic **before** calling INIT or starting
LOGINOUT/DCL. The full executive, RMS, ACP integration and DECnet Phase IV
remain incomplete. The original source index still tracks **166** entries;
this platform integration does not count as 23 new fully ported modules.

Host checks:
```
make all files1186check files1187check bootcheck imagecheck sysnativecheck
python3 tools/gen_source_coverage.py
python3 tests/test_source_audit.py
```

One-QEMU-runner check when QEMU is installed:
```
make qemu-sysnative
```
It requires a real QEMU system emulator and captures `qemu-m88-serial.log`.
QEMU was unavailable in the M88 local build environment, so this guest check
is **not yet verified**. Last actual QEMU boot: M81, which lacked SYS.EXE.

M89: SYSBOOT now reads and loads the independent partial INILOA.EXE from
Files-11 as FID 12, with INDEXF.SYS extended to retain file headers. The
CPU-specific INI$IOMAP bus discovery is a partial native IA-32 counterpart;
it is NOT run at boot because source-ordered INIT is incomplete. Both
images are ELF32 IA-32. Host disk, load and map tests pass; live M89 QEMU
confirmation is not yet established. The tests must not simulate a login.
